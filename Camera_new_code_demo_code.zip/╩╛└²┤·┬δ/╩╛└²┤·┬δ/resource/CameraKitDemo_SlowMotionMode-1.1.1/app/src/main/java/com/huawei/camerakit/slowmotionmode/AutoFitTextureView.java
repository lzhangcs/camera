/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.slowmotionmode;

import android.content.Context;
import android.util.AttributeSet;
import android.view.TextureView;

/**
 * auto fit textureView for camera preview
 */
public class AutoFitTextureView extends TextureView {
    private int mRatioWidth = 0;

    private int mRatioHeight = 0;

    /**
     * AutoFitTextureView constructor method with context parameter
     *
     * @param context context
     */
    public AutoFitTextureView(Context context) {
        this(context, null);
    }

    /**
     * AutoFitTextureView constructor method with context and attributes parameters
     *
     * @param context context
     * @param attrs attributes set
     */
    public AutoFitTextureView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * AutoFitTextureView constructor method with context and attributes and defStyle parameters
     *
     * @param context context
     * @param attrs attributes set
     * @param defStyle customized style
     */
    public AutoFitTextureView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    /**
     * setting the view's width and height
     *
     * @param width width
     * @param height height
     */
    public void setAspectRatio(int width, int height) {
        if ((width < 0) || (height < 0)) {
            throw new IllegalArgumentException("Size cannot be negative.");
        }
        mRatioWidth = width;
        mRatioHeight = height;
        requestLayout();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        if ((0 == mRatioWidth) || (0 == mRatioHeight)) {
            setMeasuredDimension(width, height);
        } else {
            if (width < height * mRatioWidth / mRatioHeight) {
                setMeasuredDimension(width, width * mRatioHeight / mRatioWidth);
            } else {
                setMeasuredDimension(height * mRatioWidth / mRatioHeight, height);
            }
        }
    }
}
