/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.slowmotionmode;

import android.content.DialogInterface;
import android.graphics.SurfaceTexture;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.huawei.camera.camerakit.ActionDataCallback;
import com.huawei.camera.camerakit.ActionStateCallback;
import com.huawei.camera.camerakit.CameraKit;
import com.huawei.camera.camerakit.Metadata;
import com.huawei.camera.camerakit.Mode;
import com.huawei.camera.camerakit.ModeCharacteristics;
import com.huawei.camera.camerakit.ModeConfig;
import com.huawei.camera.camerakit.ModeStateCallback;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.stream.Collectors;

/**
 * Slow Motion Mode demo
 */
public class SlowMotionActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = SlowMotionActivity.class.getSimpleName();

    private static final @Mode.Type int CURRENT_MODE_TYPE = Mode.Type.SLOW_MOTION_MODE;

    private static final long PREVIEW_SURFACE_READY_TIMEOUT = 5000L;

    private AutoFitTextureView textureView;

    private Button recordOrStop;

    private HandlerThread backgroundThread;

    private HandlerThread statusCbThread;

    private HandlerThread dataCbThread;

    private HandlerThread modeCbThread;

    private Handler backgroundHandler;

    private Handler statusCbHandler;

    private Handler dataCbHandler;

    private Handler modeCbHandler;

    private CameraKit cameraKit;

    private String cameraId = "0";

    private Mode currentMode;

    private HwRecorder hwRecorder;

    private ModeCharacteristics modeCharacteristics;

    private Size recordSize;

    private int recordFps;

    private Size previewSize;

    private Surface previewSurface;

    private Surface videoSurface;

    private int orientation;

    private ModeConfig.Builder modeConfigBuilder;

    private OrientationEventListener orientationEventListener;

    private final ConditionVariable previewSurfaceChangedDone = new ConditionVariable();

    private boolean isFirstRecording = true;

    private Semaphore prepareModeConfigLock = new Semaphore(1);

    private ModeStateCallback modeStateCallback = new ModeStateCallback() {
        @Override
        public void onCreated(Mode mode) {
            Log.d(TAG, "onCreated: mode created " + mode);
            currentMode = mode;
            prepareConfig();
            configureMode();
        }

        @Override
        public void onConfigured(Mode mode) {
            currentMode.startPreview();
        }

        @Override
        public void onReleased(Mode mode) {
            super.onReleased(mode);
        }
    };

    private ActionStateCallback actionStateCallback = new ActionStateCallback() {
        @Override
        public void onRecording(Mode mode, int state, RecordingResult result) {
            super.onRecording(mode, state, result);
        }
    };

    private ActionDataCallback actionDataCallback = new ActionDataCallback() {
        @Override
        public void onImageAvailable(Mode mode, int type, Image image) {
            super.onImageAvailable(mode, type, image);
        }
    };

    private TextureView.SurfaceTextureListener listener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
            backgroundHandler
                .post(() -> cameraKit.createMode(cameraId, CURRENT_MODE_TYPE, modeStateCallback, modeCbHandler));
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {
            previewSurfaceChangedDone.open();
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            return true;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }
    };

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.record_stop:
                if (recordOrStop.getText().equals(getResources().getString(R.string.button_record))) {
                    recordOrStop.setText(R.string.button_stop);

                    backgroundHandler.post(() -> {
                        if (!isFirstRecording) {
                            hwRecorder.prepare(recordSize, videoSurface,
                                CameraKitHelper.getImageRotation(
                                    modeCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION), orientation),
                                recordFps);
                        }
                        isFirstRecording = false;
                        currentMode.startRecording();
                        hwRecorder.start();
                    });
                } else {
                    recordOrStop.setText(R.string.button_record);
                    backgroundHandler.post(() -> {
                        currentMode.stopRecording();
                        hwRecorder.stop();
                    });
                    Toast.makeText(this, CameraKitHelper.getCurrentVideoFileName() + " saved", Toast.LENGTH_SHORT)
                        .show();
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textureView = findViewById(R.id.texture);
        recordOrStop = findViewById(R.id.record_stop);
        startBackgroundThreads();
        recordOrStop.setOnClickListener(this);
        orientationEventListener = new OrientationEventListener(this, SensorManager.SENSOR_DELAY_NORMAL) {
            @Override
            public void onOrientationChanged(int orientation) {
                SlowMotionActivity.this.orientation = orientation;
            }
        };
        if (orientationEventListener.canDetectOrientation()) {
            orientationEventListener.enable();
            Log.d(TAG, "onCreate: mOrientationEventListener enabled.");
        } else {
            orientationEventListener.disable();
            Log.d(TAG, "onCreate: mOrientationEventListener cannot detect Orientation.");
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initHandlers();
        recordOrStop.setText(R.string.button_record);
        isFirstRecording = true;
        if (!PermissionHelper.hasPermission(this)) {
            PermissionHelper.requestPermission(this);
            return;
        } else {
            CameraKitHelper.initStoreDir(getApplicationContext());
            CameraKitHelper.checkImageDirectoryExists();
            if (!initCameraKit()) {
                showAlertWarning(getString(R.string.warning_str));
                return;
            }
            hwRecorder = new HwRecorder();
        }
        if (!Arrays.stream(cameraKit.getSupportedModes(cameraId)).boxed().collect(Collectors.toList()).contains(
            CURRENT_MODE_TYPE)) {
            showAlertWarning(getString(R.string.mode_not_support));
            return;
        }
        if (textureView.isAvailable()) {
            Log.d(TAG, "onResume: textureView is available");
            backgroundHandler
                .post(() -> cameraKit.createMode(cameraId, CURRENT_MODE_TYPE, modeStateCallback, modeCbHandler));
        }
        textureView.setSurfaceTextureListener(listener);
    }

    private void showAlertWarning(String msg) {
        new AlertDialog.Builder(this).setMessage(msg)
            .setTitle("warning:")
            .setCancelable(false)
            .setPositiveButton(R.string.ok_str, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            })
            .show();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause: ");
        if (currentMode != null) {
            currentMode.release();
            currentMode = null;
        }
        if (hwRecorder != null) {
            hwRecorder.release();
            hwRecorder = null;
        }
        super.onPause();
    }

    private boolean initCameraKit() {
        cameraKit = CameraKit.getInstance(getApplicationContext());
        if (cameraKit == null) {
            Log.e(TAG, "initCamerakit: this devices not support camerakit or not installed!");
            return false;
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopBackgroundThreads();
        if (orientationEventListener != null) {
            orientationEventListener.disable();
        }
    }

    private void startBackgroundThreads() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        Log.d(TAG, "startBackgroundThreads: CameraBackground threadId = " + backgroundThread.getThreadId());
        statusCbThread = new HandlerThread("statusCB");
        statusCbThread.start();
        Log.d(TAG, "startBackgroundThreads: statusCB threadId = " + statusCbThread.getThreadId());
        dataCbThread = new HandlerThread("dataCB");
        dataCbThread.start();
        Log.d(TAG, "startBackgroundThreads: dataCB threadId = " + dataCbThread.getThreadId());
        modeCbThread = new HandlerThread("ModeCB");
        modeCbThread.start();
        Log.d(TAG, "startBackgroundThreads: ModeCB threadId = " + modeCbThread.getThreadId());
    }

    private void initHandlers() {
        Log.d(TAG, "initHandlers");
        backgroundHandler = new Handler(backgroundThread.getLooper());
        statusCbHandler = new Handler(statusCbThread.getLooper());
        dataCbHandler = new Handler(dataCbThread.getLooper());
        modeCbHandler = new Handler(modeCbThread.getLooper());
    }

    private void stopBackgroundThreads() {
        Log.d(TAG, "stopBackgroundThread: ");
        stopCameraBackgroundThread();
        stopDataCbThread();
        stopStatusCbThread();
        stopModeCbThread();
    }

    private void stopCameraBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop backgroundThread " + e.getMessage());
            }
        }
    }

    private void stopStatusCbThread() {
        if (statusCbThread != null) {
            statusCbThread.quitSafely();
            try {
                statusCbThread.join();
                statusCbThread = null;
                statusCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop statusCbThread " + e.getMessage());
            }
        }
    }

    private void stopDataCbThread() {
        if (dataCbThread != null) {
            dataCbThread.quitSafely();
            try {
                dataCbThread.join();
                dataCbThread = null;
                dataCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop dataCbThread " + e.getMessage());
            }
        }
    }

    private void stopModeCbThread() {
        if (modeCbThread != null) {
            modeCbThread.quitSafely();
            try {
                modeCbThread.join();
                modeCbThread = null;
                modeCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop dataCbThread " + e.getMessage());
            }
        }
    }

    private void prepareConfig() {
        try {
            prepareModeConfigLock.acquire();
            modeCharacteristics = cameraKit.getModeCharacteristics(cameraId, CURRENT_MODE_TYPE);
            Log.d(TAG, "activePreview: "
                + String.format(Locale.ENGLISH, CameraKitHelper.MODE_DEFAULT_PRINT, cameraId, CURRENT_MODE_TYPE));
            List<Size> previewSizes = modeCharacteristics.getSupportedPreviewSizes(SurfaceTexture.class);
            Map<Integer, List<Size>> recordSizes = modeCharacteristics.getSupportedVideoSizes(MediaRecorder.class);
            if (previewSizes != null) {
                Log.d(TAG, "activePreview: previewSizes = " + previewSizes);
            }
            if (recordSizes != null) {
                Log.d(TAG, "activePreview: recordSizes = " + recordSizes);
            }
            // choose one pair of Record Resolution as a demo
            if (recordSizes.containsKey(Metadata.FpsRange.HW_FPS_120)) {
                recordFps = Metadata.FpsRange.HW_FPS_120;
                recordSize = recordSizes.get(Metadata.FpsRange.HW_FPS_120).get(0);
            } else {
                recordFps = Metadata.FpsRange.HW_FPS_240;
                recordSize = recordSizes.get(Metadata.FpsRange.HW_FPS_240).get(0);
            }
            Log.d(TAG, "prepareConfig: recordFps = " + recordFps + ", recordSize = " + recordSize);
            preparePreviewSurface(previewSizes, recordSize);
            prepareVideoSurface();
        } catch (InterruptedException e) {
            Log.e(TAG, "prepareModeConfig fail " + e.getMessage());
        } finally {
            prepareModeConfigLock.release();
        }
    }

    private void preparePreviewSurface(List<Size> previewSizes, Size recordResolution) {
        if ((previewSizes == null) || (recordSize == null) || (previewSizes.isEmpty())) {
            return;
        }
        Size previewSizeNeeded = CameraKitHelper.getOptimalVideoPreviewSize(this, recordSize, previewSizes);
        Log.d(TAG, "preparePreviewSurface: previewSize = " + previewSizeNeeded);
        waitTextureViewSizeUpdate(previewSizeNeeded);
        SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
        if (surfaceTexture == null) {
            Log.e(TAG, "preparePreviewSurface: surfaceTexture is null");
        }
        surfaceTexture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
        previewSurface = new Surface(surfaceTexture);
    }

    private void prepareVideoSurface() {
        if ((recordSize != null) && (hwRecorder != null)) {
            videoSurface = MediaCodec.createPersistentInputSurface();
            hwRecorder.prepare(recordSize, videoSurface, CameraKitHelper.getImageRotation(
                modeCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION), orientation), recordFps);
        }
    }

    private void configureMode() {
        modeConfigBuilder = currentMode.getModeConfigBuilder();
        modeConfigBuilder.setStateCallback(actionStateCallback, statusCbHandler);
        modeConfigBuilder.setDataCallback(actionDataCallback, dataCbHandler);
        try {
            prepareModeConfigLock.acquire();
            modeConfigBuilder.setVideoFps(recordFps);
            modeConfigBuilder.addVideoSurface(videoSurface);
            modeConfigBuilder.addPreviewSurface(previewSurface);
            currentMode.configure();
        } catch (InterruptedException e) {
            Log.e(TAG, "configureMode: " + e.getMessage());
        } finally {
            prepareModeConfigLock.release();
        }
    }

    private void refreshTextureView(int height, int width) {
        ConditionVariable conditionVariable = new ConditionVariable();
        conditionVariable.close();
        runOnUiThread(() -> {
            textureView.setAspectRatio(height, width);
            conditionVariable.open();
        });
        conditionVariable.block();
    }

    /**
     * wait for textureView updated
     *
     * @param targetPreviewSize preview size
     */
    private void waitTextureViewSizeUpdate(Size targetPreviewSize) {
        refreshTextureView(targetPreviewSize.getHeight(), targetPreviewSize.getWidth());
        if (previewSize == null) {
            Log.d(TAG, "mPreviewSize is null");
            previewSize = targetPreviewSize;
            previewSurfaceChangedDone.close();
            previewSurfaceChangedDone.block(PREVIEW_SURFACE_READY_TIMEOUT);
        } else {
            if (targetPreviewSize.getHeight() * previewSize.getWidth()
                - targetPreviewSize.getWidth() * previewSize.getHeight() == 0) {
                Log.d(TAG, "mPreviewSize ratio not change");
                previewSize = targetPreviewSize;
            } else {
                Log.d(TAG, "mPreviewSize changed");
                previewSize = targetPreviewSize;
                previewSurfaceChangedDone.close();
                previewSurfaceChangedDone.block(PREVIEW_SURFACE_READY_TIMEOUT);
            }
        }
    }
}
