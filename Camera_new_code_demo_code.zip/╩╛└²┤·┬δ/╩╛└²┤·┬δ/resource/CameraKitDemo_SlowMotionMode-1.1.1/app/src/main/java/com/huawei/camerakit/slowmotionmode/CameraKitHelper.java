/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.slowmotionmode;

import android.content.Context;
import android.graphics.Point;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * CameraKit tools functions
 */
public class CameraKitHelper {
    /**
     * screen orientations
     */
    public static final SparseIntArray ORIENTATIONS = new SparseIntArray();

    /**
     * log format
     */
    public static final String MODE_DEFAULT_PRINT = "mCurrentCameraId = %s; mCurrentModeType = %d";

    private static final String TAG = CameraKitHelper.class.getSimpleName();

    private static final int ROTATION_DEGREE_0 = 0;

    private static final int ROTATION_DEGREE_90 = 90;

    private static final int ROTATION_DEGREE_180 = 180;

    private static final int ROTATION_DEGREE_270 = 270;

    private static final int ROTATION_DEGREE_360 = 360;

    private static final int ROTATION_DEGREE_30 = 30;

    private static final double RATIO_TOLERANCE = 0.05;

    private static final int MAX_RESOLUTION_VALUE = 65536;

    private static String videoFilePath;

    /**
     * dirs for file to be saved
     */
    private static String imageSaveDir = "";

    static {
        ORIENTATIONS.append(Surface.ROTATION_0, ROTATION_DEGREE_90);
        ORIENTATIONS.append(Surface.ROTATION_90, ROTATION_DEGREE_0);
        ORIENTATIONS.append(Surface.ROTATION_180, ROTATION_DEGREE_270);
        ORIENTATIONS.append(Surface.ROTATION_270, ROTATION_DEGREE_180);
    }

    private CameraKitHelper() {
    }

    /**
     * 初始化存储目录
     *
     * @param context 应用上下文
     */
    public static void initStoreDir(Context context) {
        Objects.requireNonNull(context, "app context should be not null!");
        File dir = context.getExternalFilesDir(null);
        if (dir == null) {
            Log.e(TAG, "context.getExternalFilesDir error");
            return;
        }
        String savePath;
        try {
            savePath = dir.getCanonicalPath();
        } catch (IOException e) {
            Log.e(TAG, "initStoreDir error" + e.getMessage());
            return;
        }
        imageSaveDir = savePath + File.separator + "HwCameraKit" + File.separator;
    }

    /**
     * 检查文件路径是否存在
     */
    public static void checkImageDirectoryExists() {
        File imageDirectory = new File(imageSaveDir);
        if (!imageDirectory.exists()) {
            if (imageDirectory.mkdirs()) {
                Log.d(TAG, "imageSaveDir:" + imageSaveDir);
            }
        }
    }

    /**
     * get Video file path
     *
     * @return video file path
     */
    public static String getVideoName() {
        Log.d(TAG, "setmFileName: ");
        String prefixFile;
        prefixFile = "Default";
        videoFilePath = imageSaveDir + prefixFile + "_video_" + System.currentTimeMillis() + ".mp4";
        return videoFilePath;
    }

    /**
     * get current video file name
     *
     * @return video file path
     */
    public static String getCurrentVideoFileName() {
        return videoFilePath;
    }

    /**
     * choose Optimal preview size according to record size
     *
     * @param context context
     * @param videoSize record resolution
     * @param cameraPreviewSupports preview sizes supported by the camera
     * @return preview size
     */
    public static Size getOptimalVideoPreviewSize(Context context, Size videoSize, List<Size> cameraPreviewSupports) {
        if ((context == null) || (videoSize == null) || (cameraPreviewSupports == null)) {
            Log.e(TAG, "getOptimalVideoPreviewSize: error, some parameter is null");
            return null;
        }

        Object obj = context.getSystemService(Context.WINDOW_SERVICE);
        WindowManager wm = null;
        if (obj instanceof WindowManager) {
            wm = (WindowManager) obj;
        }
        if (wm == null) {
            return null;
        }
        Display display = wm.getDefaultDisplay();
        if (display == null) {
            return null;
        }
        Point displaySize = new Point();
        display.getSize(displaySize);

        int maxPreviewWidth = displaySize.x;
        int maxPreviewHeight = displaySize.y;

        Size optimalSize = null;
        int maxValue = MAX_RESOLUTION_VALUE;
        double videoRatio = ((double) (videoSize.getWidth())) / ((double) (videoSize.getHeight()));
        for (Size size : cameraPreviewSupports) {
            if ((size.getWidth() > maxPreviewWidth) && (size.getHeight() > maxPreviewHeight)) {
                continue;
            }
            if (size.getHeight() > maxValue) {
                continue;
            } else if (Math
                .abs(((double) (size.getWidth())) / ((double) (size.getHeight())) - videoRatio) > RATIO_TOLERANCE) {
                continue;
            } else if (optimalSize == null) {
                optimalSize = size;
                continue;
            }
            if ((Math.abs(size.getHeight() - videoSize.getHeight()) <= Math
                .abs(optimalSize.getHeight() - videoSize.getHeight()))
                && (Math.abs(size.getWidth() - videoSize.getWidth()) <= Math
                    .abs(optimalSize.getWidth() - videoSize.getWidth()))) {
                optimalSize = size;
            }
        }
        Log.i(TAG, "optimal video preview size = "
            + ((optimalSize == null) ? "null" : (optimalSize.getWidth() + "x" + optimalSize.getHeight())));
        return optimalSize;
    }

    /**
     * get image rotation degree
     *
     * @param sensorOrientation sensor orientation
     * @param rotationDegree phone rotated degree
     * @return image rotation degree
     */
    public static int getImageRotation(int sensorOrientation, int rotationDegree) {
        Log.d(TAG, "getImageRotation: mSensorOrientation = " + sensorOrientation);
        int orientation = 0;
        if ((rotationDegree > (ROTATION_DEGREE_360 - ROTATION_DEGREE_30)) || (rotationDegree < ROTATION_DEGREE_30)) {
            orientation = ROTATION_DEGREE_0;
        } else if ((rotationDegree > (ROTATION_DEGREE_90 - ROTATION_DEGREE_30))
            && (rotationDegree < (ROTATION_DEGREE_90 + ROTATION_DEGREE_30))) {
            orientation = ROTATION_DEGREE_90;
        } else if ((rotationDegree > (ROTATION_DEGREE_180 - ROTATION_DEGREE_30))
            && (rotationDegree < (ROTATION_DEGREE_180 + ROTATION_DEGREE_30))) {
            orientation = ROTATION_DEGREE_180;
        } else if ((rotationDegree > (ROTATION_DEGREE_270 - ROTATION_DEGREE_30))
            && (rotationDegree < (ROTATION_DEGREE_270 + ROTATION_DEGREE_30))) {
            orientation = ROTATION_DEGREE_270;
        }
        int imageRotation = (orientation + sensorOrientation) % ROTATION_DEGREE_360;
        Log.d(TAG, "getImageRotation: imageRotation = " + imageRotation);
        return imageRotation;
    }
}
