/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.slowmotionmode;

import android.media.MediaRecorder;
import android.util.Log;
import android.util.Size;
import android.view.Surface;

import java.io.File;
import java.io.IOException;

/**
 * mediaRecorder wrapper
 */
public class HwRecorder {
    private static final String TAG = "HwRecorder";

    private static final int VIDEO_ENCODING_BIT_RATE = 10000000;

    private MediaRecorder mMediaRecorder;

    private String mVideoFile;

    HwRecorder() {
        mMediaRecorder = new MediaRecorder();
    }

    /**
     * initialize mediaRecorder
     *
     * @param videoSize record size
     * @param surface record surface
     * @param orientation orientation degree
     * @param frameRate record frame
     */
    public void prepare(Size videoSize, Surface surface, int orientation, int frameRate) {
        try {
            mMediaRecorder.reset();
            mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mVideoFile = CameraKitHelper.getVideoName();
            mMediaRecorder.setOutputFile(mVideoFile);
            mMediaRecorder.setVideoEncodingBitRate(VIDEO_ENCODING_BIT_RATE);
            mMediaRecorder.setVideoFrameRate(frameRate);
            mMediaRecorder.setVideoSize(videoSize.getWidth(), videoSize.getHeight());
            mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mMediaRecorder.setOrientationHint(orientation);
            mMediaRecorder.setInputSurface(surface);
            mMediaRecorder.prepare();
            Log.d(TAG, "mMediaRecorder prepare done!");
        } catch (IOException e) {
            Log.e(TAG, "mMediaRecorder prepare ioe exception " + e.getMessage());
        } catch (IllegalStateException e) {
            Log.e(TAG, "mMediaRecorder prepare state error");
        }
    }

    /**
     * 开始录像
     *
     * @return 操作是否成功
     */
    public boolean start() {
        try {
            mMediaRecorder.start();
            Log.d(TAG, "Recording starts!");
            return true;
        } catch (IllegalStateException e) {
            Log.e(TAG, "mMediaRecorder prepare not well!");
            clearInvalidFile();
            return false;
        } finally {
            Log.d(TAG, "start end");
        }
    }

    private void clearInvalidFile() {
        if (!mVideoFile.isEmpty()) {
            File vidFile = new File(mVideoFile);
            if (vidFile.exists()) {
                vidFile.delete();
                mVideoFile = "";
                Log.d(TAG, "invalid video file deleted!");
            }
        }
    }

    /**
     * stop Recording
     *
     * @return recording stopped or not
     */
    public boolean stop() {
        try {
            mMediaRecorder.stop();
            return true;
        } catch (IllegalStateException e) {
            Log.e(TAG, "mMediaRecorder stop state error");
            return false;
        } catch (RuntimeException stopException) {
            Log.e(TAG, "going to clean up the invalid output file");
            clearInvalidFile();
            return false;
        } finally {
            Log.d(TAG, "stopRecord end");
        }
    }

    /**
     * release mediaRecorder
     */
    public void release() {
        Log.d(TAG, "[schedule] releaseMediaRecorder");
        if (mMediaRecorder != null) {
            Log.v(TAG, "Releasing media recorder.");
            try {
                mMediaRecorder.reset();
            } catch (IllegalStateException e) {
                Log.e(TAG, "media recorder maybe has been released! msg=" + e.getMessage());
            }
            mMediaRecorder.release();
            mMediaRecorder = null;
        }
    }
}
