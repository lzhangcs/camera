/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.superslowmotionmode;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

/**
 * app tool functions
 */
public class AppUtil {
    private static final String TAG = AppUtil.class.getSimpleName();

    private static float displayDensity = 0F;

    private AppUtil() {
    }

    /**
     * init screen info
     *
     * @param context context
     */
    public static void resetScreenInfo(Context context) {
        if (context == null) {
            Log.w(TAG, "Reset screen info: param is null.");
            return;
        }
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (wm != null) {
            wm.getDefaultDisplay().getMetrics(metrics);
        }
        displayDensity = metrics.density;
        Log.d(TAG, "resetScreenInfo: displayDensity = " + displayDensity);
    }

    /**
     * Parse dp to pixel.
     *
     * @param dp The dp size.
     * @return The pixel size converted from dp.
     */
    public static int dpToPixel(int dp) {
        return Math.round(displayDensity * dp);
    }

    /**
     * Parse dp to pixel.
     *
     * @param dp The dp size.
     * @return The pixel size converted from dp.
     */
    public static int dpToPixel(float dp) {
        return Math.round(displayDensity * dp);
    }

    /**
     * get proper value
     *
     * @param x current value
     * @param min min value
     * @param max max value
     * @return result value
     */
    public static int clamp(int x, int min, int max) {
        if (x > max) {
            return max;
        }
        if (x < min) {
            return min;
        }
        return x;
    }

    /**
     * post runnable to UI thread
     *
     * @param runnable event runnable
     */
    public static void runOnUithread(Runnable runnable) {
        new Handler(Looper.getMainLooper()).post(runnable);
    }
}
