/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.superslowmotionmode;

import android.content.DialogInterface;
import android.graphics.SurfaceTexture;
import android.media.Image;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.huawei.camera.camerakit.ActionDataCallback;
import com.huawei.camera.camerakit.ActionStateCallback;
import com.huawei.camera.camerakit.CameraKit;
import com.huawei.camera.camerakit.Metadata;
import com.huawei.camera.camerakit.Mode;
import com.huawei.camera.camerakit.ModeCharacteristics;
import com.huawei.camera.camerakit.ModeConfig;
import com.huawei.camera.camerakit.ModeStateCallback;
import com.huawei.camera.camerakit.RequestKey;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.stream.Collectors;

/**
 * SuperSlowDemo activity
 */
public class SuperSlowDemoActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = SuperSlowDemoActivity.class.getSimpleName();

    private static final @Mode.Type int CURRENT_MODE_TYPE = Mode.Type.SUPER_SLOW_MOTION;

    private static final long PREVIEW_SURFACE_READY_TIMEOUT = 5000L;

    private static final float MIN_RATIO = 1.0F / 3;

    private static final float MAX_RATIO = 1.0F;

    private static final int MAX_SEEK_BAR_PROGRESS = 100;

    private AutoFitTextureView textureView;

    private Button recordOrStop;

    private HandlerThread backgroundThread;

    private HandlerThread statusCbThread;

    private HandlerThread dataCbThread;

    private HandlerThread modeCbThread;

    private Handler backgroundHandler;

    private Handler statusCbHandler;

    private Handler dataCbHandler;

    private Handler modeCbHandler;

    private CameraKit cameraKit;

    private String cameraId = "0";

    private Mode currentMode;

    private ModeCharacteristics modeCharacteristics;

    private Size recordSize;

    private int recordFps;

    private Size previewSize;

    private Surface previewSurface;

    private ModeConfig.Builder modeConfigBuilder;

    private final ConditionVariable previewSurfaceChangedDone = new ConditionVariable();

    private Semaphore prepareModeConfigLock = new Semaphore(1);

    private boolean isAutoWorkMode = false;

    private String saveFilePath;

    private PreviewViewWithRect previewViewWithRect;

    private SeekBar checkLengthRatioSeekBar;

    private TextView checkLenRatioIndicator;

    private boolean hasStarted = false;

    private ModeStateCallback modeStateCallback = new ModeStateCallback() {
        @Override
        public void onCreated(Mode mode) {
            Log.d(TAG, "onCreated: mode created " + mode);
            currentMode = mode;
            prepareConfig();
            configureMode();
            // for example, zoomValue = 1.0f
            mode.setZoom(1.0f);
        }

        @Override
        public void onConfigured(Mode mode) {
            currentMode.startPreview();
            runOnUiThread(() -> {
                initAutoTriggerSpinner();
                initCheckLenRatioSeekerBar();
            });
        }

        @Override
        public void onReleased(Mode mode) {
            super.onReleased(mode);
        }
    };

    private ActionStateCallback actionStateCallback = new ActionStateCallback() {
        @Override
        public void onRecording(Mode mode, int state, RecordingResult result) {
            Log.d(TAG, "onRecording: state = " + state);
            switch (state) {
                case RecordingResult.State.ERROR_FILE_IO:
                case RecordingResult.State.ERROR_UNKNOWN:
                    throw new IllegalStateException("error!");
                case RecordingResult.State.ERROR_RECORDING_NOT_READY:
                    runOnUiThread(
                        () -> Toast.makeText(SuperSlowDemoActivity.this, R.string.status_not_ready, Toast.LENGTH_SHORT)
                            .show());
                    break;
                case RecordingResult.State.RECORDING_READY:
                    runOnUiThread(() -> recordOrStop.setEnabled(true));
                    break;
                case RecordingResult.State.RECORDING_STARTED:
                    runOnUiThread(() -> {
                        recordOrStop.setEnabled(false);
                        hasStarted = true;
                        Toast.makeText(SuperSlowDemoActivity.this, R.string.status_started, Toast.LENGTH_SHORT).show();
                    });
                    break;
                case RecordingResult.State.RECORDING_STOPPED:
                    runOnUiThread(() -> {
                        if (!hasStarted && isAutoWorkMode) {
                            previewViewWithRect.canTouch(true);
                            checkLengthRatioSeekBar.setEnabled(true);
                            findViewById(R.id.auto_trigger_spinner).setEnabled(true);
                        }
                        Toast.makeText(SuperSlowDemoActivity.this, R.string.status_stopped, Toast.LENGTH_SHORT).show();
                    });
                    break;
                case RecordingResult.State.RECORDING_COMPLETED:
                    runOnUiThread(
                        () -> Toast.makeText(SuperSlowDemoActivity.this, R.string.status_completed, Toast.LENGTH_SHORT)
                            .show());
                    break;
                case RecordingResult.State.RECORDING_FILE_SAVED:
                    runOnUiThread(() -> {
                        checkLengthRatioSeekBar.setEnabled(true);
                        previewViewWithRect.canTouch(true);
                        Toast.makeText(SuperSlowDemoActivity.this, saveFilePath + " saved", Toast.LENGTH_SHORT).show();
                        recordOrStop.setText(R.string.button_record);
                        recordOrStop.setEnabled(true);
                        findViewById(R.id.auto_trigger_spinner).setEnabled(true);
                    });
                    break;
                default:
                    break;
            }
        }
    };

    private ActionDataCallback actionDataCallback = new ActionDataCallback() {
        @Override
        public void onImageAvailable(Mode mode, int type, Image image) {
            super.onImageAvailable(mode, type, image);
        }
    };

    private TextureView.SurfaceTextureListener listener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
            backgroundHandler
                .post(() -> cameraKit.createMode(cameraId, CURRENT_MODE_TYPE, modeStateCallback, modeCbHandler));
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {
            previewSurfaceChangedDone.open();
        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            return true;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }
    };

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.record_stop:
                hasStarted = false;
                if (isAutoWorkMode) {
                    if (recordOrStop.getText().equals(getResources().getString(R.string.button_record))) {
                        previewViewWithRect.canTouch(false);
                        checkLengthRatioSeekBar.setEnabled(false);
                        findViewById(R.id.auto_trigger_spinner).setEnabled(false);
                        backgroundHandler.post(() -> {
                            currentMode.setParameter(RequestKey.HW_SUPER_SLOW_CHECK_AREA,
                                previewViewWithRect.getCurrentCheckArea());
                            currentMode.startRecording(new File(getVideoFileName()));
                        });
                        recordOrStop.setText(R.string.button_stop);
                        findViewById(R.id.auto_trigger_spinner).setEnabled(false);
                    } else {
                        backgroundHandler.post(() -> currentMode.stopRecording());
                        recordOrStop.setText(R.string.button_record);
                    }
                } else {
                    findViewById(R.id.auto_trigger_spinner).setEnabled(false);
                    recordOrStop.setEnabled(false);
                    currentMode.startRecording(new File(getVideoFileName()));
                }
                break;
            default:
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textureView = findViewById(R.id.texture);
        recordOrStop = findViewById(R.id.record_stop);
        previewViewWithRect = findViewById(R.id.preview_with_rect);
        checkLengthRatioSeekBar = findViewById(R.id.check_ratio_seek_bar);
        checkLenRatioIndicator = findViewById(R.id.check_ratio_indicator);
        startBackgroundThreads();
        recordOrStop.setOnClickListener(this);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initHandlers();
        recordOrStop.setText(R.string.button_record);
        recordOrStop.setEnabled(false);
        AppUtil.resetScreenInfo(this);
        if (!PermissionHelper.hasPermission(this)) {
            PermissionHelper.requestPermission(this);
            return;
        } else {
            if (!initCameraKit()) {
                showAlertWarning(getString(R.string.warning_str));
                return;
            }
        }
        if (!Arrays.stream(cameraKit.getSupportedModes(cameraId)).boxed().collect(Collectors.toList()).contains(
            CURRENT_MODE_TYPE)) {
            showAlertWarning(getString(R.string.mode_not_support));
            return;
        }
        if (textureView.isAvailable()) {
            Log.d(TAG, "onResume: textureView is available");
            backgroundHandler
                .post(() -> cameraKit.createMode(cameraId, CURRENT_MODE_TYPE, modeStateCallback, modeCbHandler));
        }
        textureView.setSurfaceTextureListener(listener);
    }

    private void showAlertWarning(String msg) {
        new AlertDialog.Builder(this).setMessage(msg)
            .setTitle("warning:")
            .setCancelable(false)
            .setPositiveButton(R.string.ok_str, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            })
            .show();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause: ");
        if (currentMode != null) {
            currentMode.release();
            currentMode = null;
        }
        super.onPause();
        previewViewWithRect.isAutoWorkMode(false);
    }

    private boolean initCameraKit() {
        cameraKit = CameraKit.getInstance(getApplicationContext());
        if (cameraKit == null) {
            Log.e(TAG, "initCamerakit: this devices not support camerakit or not installed!");
            return false;
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopBackgroundThreads();
    }

    private void startBackgroundThreads() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        Log.d(TAG, "startBackgroundThreads: CameraBackground threadId = " + backgroundThread.getThreadId());
        statusCbThread = new HandlerThread("statusCB");
        statusCbThread.start();
        Log.d(TAG, "startBackgroundThreads: statusCB threadId = " + statusCbThread.getThreadId());
        dataCbThread = new HandlerThread("dataCB");
        dataCbThread.start();
        Log.d(TAG, "startBackgroundThreads: dataCB threadId = " + dataCbThread.getThreadId());
        modeCbThread = new HandlerThread("ModeCB");
        modeCbThread.start();
        Log.d(TAG, "startBackgroundThreads: ModeCB threadId = " + modeCbThread.getThreadId());
    }

    private void initHandlers() {
        Log.d(TAG, "initHandlers");
        backgroundHandler = new Handler(backgroundThread.getLooper());
        statusCbHandler = new Handler(statusCbThread.getLooper());
        dataCbHandler = new Handler(dataCbThread.getLooper());
        modeCbHandler = new Handler(modeCbThread.getLooper());
    }

    private void stopBackgroundThreads() {
        Log.d(TAG, "stopBackgroundThread: ");
        stopCameraBackgroundThread();
        stopDataCbThread();
        stopStatusCbThread();
        stopModeCbThread();
    }

    private void stopCameraBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop backgroundThread " + e.getMessage());
            }
        }
    }

    private void stopStatusCbThread() {
        if (statusCbThread != null) {
            statusCbThread.quitSafely();
            try {
                statusCbThread.join();
                statusCbThread = null;
                statusCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop statusCbThread " + e.getMessage());
            }
        }
    }

    private void stopDataCbThread() {
        if (dataCbThread != null) {
            dataCbThread.quitSafely();
            try {
                dataCbThread.join();
                dataCbThread = null;
                dataCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop dataCbThread " + e.getMessage());
            }
        }
    }

    private void stopModeCbThread() {
        if (modeCbThread != null) {
            modeCbThread.quitSafely();
            try {
                modeCbThread.join();
                modeCbThread = null;
                modeCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop dataCbThread " + e.getMessage());
            }
        }
    }

    private void prepareConfig() {
        try {
            prepareModeConfigLock.acquire();
            modeCharacteristics = cameraKit.getModeCharacteristics(cameraId, CURRENT_MODE_TYPE);
            List<Size> previewSizes = modeCharacteristics.getSupportedPreviewSizes(SurfaceTexture.class);
            Map<Integer, List<Size>> recordSizes = modeCharacteristics.getSupportedVideoSizes(MediaRecorder.class);
            if (previewSizes != null) {
                Log.d(TAG, "activePreview: previewSizes = " + previewSizes);
            }
            if (recordSizes != null) {
                Log.d(TAG, "activePreview: recordSizes = " + recordSizes);
            }
            // choose one pair of Record Resolution as a demo
            if (recordSizes.containsKey(Metadata.FpsRange.HW_FPS_960)) {
                recordFps = Metadata.FpsRange.HW_FPS_960;
                recordSize = recordSizes.get(Metadata.FpsRange.HW_FPS_960).get(0);
            } else {
                Log.e(TAG, "prepareConfig: Internal error");
                return;
            }
            Log.d(TAG, "prepareConfig: recordFps = " + recordFps + ", recordSize = " + recordSize);
            preparePreviewSurface(previewSizes, recordSize);
        } catch (InterruptedException e) {
            Log.e(TAG, "prepareModeConfig fail " + e.getMessage());
        } finally {
            prepareModeConfigLock.release();
        }
    }

    private void preparePreviewSurface(List<Size> previewSizes, Size recordResolution) {
        if ((previewSizes == null) || (recordSize == null) || (previewSizes.isEmpty())) {
            return;
        }
        if (!previewSizes.contains(recordResolution)) {
            Log.e(TAG, "preparePreviewSurface: the previewSize and recordSize should be the same, Internal error!");
            return;
        }
        Size previewSizeNeeded = recordResolution;
        Log.d(TAG, "preparePreviewSurface: previewSize = " + previewSizeNeeded);
        waitTextureViewSizeUpdate(previewSizeNeeded);
        SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
        if (surfaceTexture == null) {
            Log.e(TAG, "preparePreviewSurface: surfaceTexture is null");
        }
        surfaceTexture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
        previewSurface = new Surface(surfaceTexture);
    }

    private void configureMode() {
        modeConfigBuilder = currentMode.getModeConfigBuilder();
        modeConfigBuilder.setStateCallback(actionStateCallback, statusCbHandler);
        modeConfigBuilder.setDataCallback(actionDataCallback, dataCbHandler);
        try {
            prepareModeConfigLock.acquire();
            modeConfigBuilder.setVideoFps(recordFps);
            modeConfigBuilder.addVideoSize(recordSize);
            modeConfigBuilder.addPreviewSurface(previewSurface);
            currentMode.configure();
        } catch (InterruptedException e) {
            Log.e(TAG, "configureMode: " + e.getMessage());
        } finally {
            prepareModeConfigLock.release();
        }
    }

    private void refreshTextureView(int height, int width) {
        ConditionVariable conditionVariable = new ConditionVariable();
        conditionVariable.close();
        runOnUiThread(() -> {
            textureView.setAspectRatio(height, width);
            conditionVariable.open();
        });
        conditionVariable.block();
    }

    /**
     * wait for textureView updated
     *
     * @param targetPreviewSize preview size
     */
    private void waitTextureViewSizeUpdate(Size targetPreviewSize) {
        refreshTextureView(targetPreviewSize.getHeight(), targetPreviewSize.getWidth());
        if (previewSize == null) {
            Log.d(TAG, "mPreviewSize is null");
            previewSize = targetPreviewSize;
            previewSurfaceChangedDone.close();
            previewSurfaceChangedDone.block(PREVIEW_SURFACE_READY_TIMEOUT);
        } else {
            if (targetPreviewSize.getHeight() * previewSize.getWidth()
                - targetPreviewSize.getWidth() * previewSize.getHeight() == 0) {
                Log.d(TAG, "mPreviewSize ratio not change");
                previewSize = targetPreviewSize;
            } else {
                Log.d(TAG, "mPreviewSize changed");
                previewSize = targetPreviewSize;
                previewSurfaceChangedDone.close();
                previewSurfaceChangedDone.block(PREVIEW_SURFACE_READY_TIMEOUT);
            }
        }
    }

    private String getVideoFileName() {
        File dir = getExternalFilesDir(null);
        if (dir == null) {
            Log.e(TAG, "getVideoFile: error");
            return "";
        }
        try {
            saveFilePath = dir.getCanonicalPath() + File.separator + "SuperSlow_" + System.currentTimeMillis() + ".mp4";
        } catch (IOException e) {
            Log.e(TAG, "getVideoFileName: " + e.getMessage());
            return "";
        }
        return saveFilePath;
    }

    private void initAutoTriggerSpinner() {
        if (!modeCharacteristics.getSupportedParameters().contains(RequestKey.HW_SUPER_SLOW_CHECK_AREA)) {
            return;
        }
        initSpinner(R.id.auto_trigger_spinner, booleanToList(true, R.string.autoTriggerOff, R.string.autoTriggerOn),
            new SpinnerOperation() {
                @Override
                public void doOperation(String text) {
                    isAutoWorkMode = text.equals(getString(R.string.autoTriggerOn));
                    previewViewWithRect.isAutoWorkMode(isAutoWorkMode);

                    if (!isAutoWorkMode) {
                        checkLengthRatioSeekBar.setVisibility(View.INVISIBLE);
                        checkLenRatioIndicator.setVisibility(View.INVISIBLE);
                        previewViewWithRect.canTouch(false);
                    } else {
                        boolean contain7680 = modeCharacteristics.getSupportedVideoSizes(MediaRecorder.class)
                            .containsKey(Metadata.FpsRange.HW_FPS_7680);
                        if (contain7680) {
                            checkLengthRatioSeekBar.setVisibility(View.VISIBLE);
                            checkLenRatioIndicator.setVisibility(View.VISIBLE);
                            checkLengthRatioSeekBar.setEnabled(true);
                            Toast.makeText(SuperSlowDemoActivity.this, R.string.show_tip, Toast.LENGTH_LONG).show();
                        }
                        previewViewWithRect.canTouch(true);
                    }
                }
            });
    }

    private List<String> booleanToList(boolean isSupport, int offId, int onId) {
        List<String> lists = new ArrayList<>(0);
        if (isSupport) {
            lists.add(getString(offId));
            lists.add(getString(onId));
        }
        return lists;
    }

    private void initSpinner(int resId, List<String> list, SpinnerOperation spinnerOperation) {
        final Spinner spinner = findViewById(resId);
        spinner.setVisibility(View.VISIBLE);
        if (list.size() == 0) {
            spinner.setVisibility(View.GONE);
            return;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item, R.id.itemText, list);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = spinner.getItemAtPosition(position).toString();
                spinnerOperation.doOperation(text);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void initCheckLenRatioSeekerBar() {
        if (!modeCharacteristics.getSupportedVideoSizes(MediaRecorder.class)
            .containsKey(Metadata.FpsRange.HW_FPS_7680)) {
            return;
        }
        checkLengthRatioSeekBar.setProgress(0);
        checkLengthRatioSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seek, int progress, boolean isFromUser) {
                float ratio = MIN_RATIO + (1.0f * progress / MAX_SEEK_BAR_PROGRESS) * (MAX_RATIO - MIN_RATIO);
                checkLenRatioIndicator.setText("check ratio: " + String.format(Locale.ENGLISH, "%.2f", ratio));
                Log.d(TAG, "onProgressChanged: check ratio = " + ratio);
                previewViewWithRect.setRatio(ratio);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seek) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seek) {
            }
        });
    }
}
