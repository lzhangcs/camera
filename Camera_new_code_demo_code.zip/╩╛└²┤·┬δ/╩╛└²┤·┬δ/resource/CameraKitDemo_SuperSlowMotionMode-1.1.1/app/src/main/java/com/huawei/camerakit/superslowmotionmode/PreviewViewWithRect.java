/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.superslowmotionmode;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;

/**
 * super slow preview with rectangle check area
 */
public class PreviewViewWithRect extends RelativeLayout {
    private static final String TAG = PreviewViewWithRect.class.getSimpleName();

    private static final Rect EMPTY_RECT = new Rect(0, 0, 0, 0);

    private static final float MIN_RATIO = 1.0F / 3;

    private static final float HALF_MULTIPLIER = 0.5f;

    private static final int COORDINATE_LENGTH = 2000;

    private static final int COORDINATE_HALF_LENGTH = 1000;

    private AutoFitTextureView textureView;

    private OnTouchListener touchListener = new TouchListener();

    /**
     * check area in center coordinate
     */
    private Rect checkAreaCenterCoordinate;

    /**
     * rect in rectView
     */
    private Rect checkAreaPreviewCoordinate;

    private boolean isAutoWorkMode;

    private float ratio = MIN_RATIO;

    private RectView rectView;

    /**
     * PreviewViewWithRect constructor method with context parameter
     *
     * @param context context
     */
    public PreviewViewWithRect(Context context) {
        this(context, null);
    }

    /**
     * PreviewViewWithRect constructor method with context and attributes parameters
     *
     * @param context context
     * @param attrs attributes set
     */
    public PreviewViewWithRect(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /**
     * AutoFitTextureView constructor method with context and attributes and defStyle parameters
     *
     * @param context context
     * @param attrs attributes set
     * @param defStyleAttr customized style attribute
     */
    public PreviewViewWithRect(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private void defaultRect() {
        int previewWidth = textureView.getWidth();
        int previewHeight = textureView.getHeight();
        Log.d(TAG, "defaultRect: previewWidth = " + previewWidth + ", previewHeight = " + previewHeight);
        if ((previewWidth != 0) && (previewHeight != 0)) {
            int maxLength = Math.min(previewWidth, previewHeight);
            int checkAreaLen = (int) (maxLength * MIN_RATIO);
            Log.d(TAG, "defaultRect: checkArea length = " + checkAreaLen);
            int halfEdge = (int) (checkAreaLen * HALF_MULTIPLIER);
            int x0 = AppUtil.clamp((int) (previewWidth * HALF_MULTIPLIER - halfEdge), 0, previewWidth - checkAreaLen);
            int y0 = AppUtil.clamp((int) (previewHeight * HALF_MULTIPLIER - halfEdge), 0, previewHeight - checkAreaLen);
            int x1 = x0 + checkAreaLen;
            int y1 = y0 + checkAreaLen;
            checkAreaPreviewCoordinate = new Rect(x0, y0, x1, y1);
        }
    }

    private void transferToCenterCoordinate() {
        if (checkAreaCenterCoordinate == null) {
            checkAreaCenterCoordinate = new Rect();
        }
        checkAreaCenterCoordinate.left =
            (int) (1.0f * checkAreaPreviewCoordinate.top * COORDINATE_LENGTH / textureView.getHeight()
                - COORDINATE_HALF_LENGTH);
        checkAreaCenterCoordinate.top = COORDINATE_HALF_LENGTH
            - (int) (1.0f * checkAreaPreviewCoordinate.right * COORDINATE_LENGTH / textureView.getWidth());
        checkAreaCenterCoordinate.right =
            (int) (1.0f * checkAreaPreviewCoordinate.bottom * COORDINATE_LENGTH / textureView.getHeight())
                - COORDINATE_HALF_LENGTH;
        checkAreaCenterCoordinate.bottom = COORDINATE_HALF_LENGTH
            - (int) (1.0f * checkAreaPreviewCoordinate.left * COORDINATE_LENGTH / textureView.getWidth());
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        initViews();
    }

    /**
     * get the current check area rect
     *
     * @return check area rect
     */
    public Rect getCurrentCheckArea() {
        if (isAutoWorkMode) {
            transferToCenterCoordinate();
            return checkAreaCenterCoordinate;
        } else {
            return EMPTY_RECT;
        }
    }

    /**
     * set isAutoWorkMode or not
     *
     * @param isAutoTrigger auto work mode or not
     */
    public void isAutoWorkMode(boolean isAutoTrigger) {
        isAutoWorkMode = isAutoTrigger;
        AppUtil.runOnUithread(() -> {
            if (isAutoTrigger) {
                rectView.setVisibility(View.VISIBLE);
                if (checkAreaPreviewCoordinate == null) {
                    defaultRect();
                }
                rectView.setRectToDraw(rectToDraw());
            } else {
                rectView.setRectToDraw(EMPTY_RECT);
                rectView.setVisibility(View.INVISIBLE);
            }
        });
    }

    private Rect rectToDraw() {
        Rect rect = new Rect();
        rect.left = textureView.getLeft() + checkAreaPreviewCoordinate.left;
        rect.top = textureView.getTop() + checkAreaPreviewCoordinate.top;
        rect.right = textureView.getLeft() + checkAreaPreviewCoordinate.right;
        rect.bottom = textureView.getTop() + checkAreaPreviewCoordinate.bottom;
        Log.d(TAG, "rectToDraw: checkArea = " + checkAreaPreviewCoordinate);
        Log.d(TAG, "rectToDraw: rect = " + rect);
        return rect;
    }

    /**
     * set ratio
     *
     * @param ratio ratio
     */
    public void setRatio(float ratio) {
        this.ratio = ratio;
        if (checkAreaPreviewCoordinate == null) {
            defaultRect();
        }
        float touchX = (checkAreaPreviewCoordinate.left + checkAreaPreviewCoordinate.right) * HALF_MULTIPLIER;
        float touchY = (checkAreaPreviewCoordinate.top + checkAreaPreviewCoordinate.bottom) * HALF_MULTIPLIER;
        int maxLength = Math.min(textureView.getWidth(), textureView.getHeight());
        int checkAreaLen = (int) (maxLength * ratio);
        Log.d(TAG, "setRatio: checkArea length = " + checkAreaLen);
        int halfEdge = (int) (checkAreaLen * HALF_MULTIPLIER);
        int x0 = AppUtil.clamp((int) touchX - halfEdge, 0, textureView.getWidth() - checkAreaLen);
        int y0 = AppUtil.clamp((int) touchY - halfEdge, 0, textureView.getHeight() - checkAreaLen);
        int x1 = x0 + checkAreaLen;
        int y1 = y0 + checkAreaLen;
        checkAreaPreviewCoordinate = new Rect(x0, y0, x1, y1);
        rectView.setRectToDraw(rectToDraw());
    }

    /**
     * set the textureView to be touchable or not
     *
     * @param touchable can touch or not
     */
    public void canTouch(boolean touchable) {
        if (touchable) {
            textureView.setOnTouchListener(touchListener);
        } else {
            textureView.setOnTouchListener(null);
        }
    }

    private void initViews() {
        Log.d(TAG, "initViews: ");
        textureView = findViewById(R.id.texture);
        rectView = findViewById(R.id.rect_view);
    }

    /**
     * touch listener
     */
    private class TouchListener implements OnTouchListener {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    int previewWidth = textureView.getWidth();
                    int previewHeight = textureView.getHeight();
                    Log.d(TAG, "onTouch: previewWidth = " + previewWidth + ", previewHeight = " + previewHeight);
                    if ((previewWidth != 0) && (previewHeight != 0)) {
                        int maxLength = Math.min(previewWidth, previewHeight);
                        int checkAreaLen = (int) (maxLength * ratio);
                        Log.d(TAG, "onTouch: checkArea length = " + checkAreaLen);
                        int halfEdge = (int) (checkAreaLen * HALF_MULTIPLIER);
                        int x0 = AppUtil.clamp((int) event.getX() - halfEdge, 0, previewWidth - checkAreaLen);
                        int y0 = AppUtil.clamp((int) event.getY() - halfEdge, 0, previewHeight - checkAreaLen);
                        int x1 = x0 + checkAreaLen;
                        int y1 = y0 + checkAreaLen;
                        checkAreaPreviewCoordinate = new Rect(x0, y0, x1, y1);
                        rectView.setRectToDraw(rectToDraw());
                    }
                    break;
                default:
                    break;
            }
            v.performClick();
            return true;
        }
    }
}
