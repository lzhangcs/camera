/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.prophotomode;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.TextureView;

import androidx.appcompat.app.AppCompatActivity;

import com.huawei.camera.camerakit.ActionDataCallback;
import com.huawei.camera.camerakit.ActionStateCallback;
import com.huawei.camera.camerakit.CameraKit;
import com.huawei.camera.camerakit.Metadata;
import com.huawei.camera.camerakit.Mode;
import com.huawei.camera.camerakit.ModeCharacteristics;
import com.huawei.camera.camerakit.ModeConfig;
import com.huawei.camera.camerakit.ModeStateCallback;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * IDE Demo Activity
 */
public class IdeDemoActivity extends AppCompatActivity {
    /**
     * The sample code can only be dragged outside the method and inside the class and needs to be compiled as a whole.
     */
    /**
     * The sample code can only be dragged outside the method and inside the class, and requires an overall drag to
     * compile successfully.
     */
    private static final String TAG = "CameraKitDemo";

    /** View for preview */
    private AutoFitTextureView mTextureView;

    /** Preview size */
    private Size mPreviewSize;

    /** record size */
    private Size mRecordSize;

    /** Capture jpeg file */
    private File mFile;

    /** CameraKit instance */
    private CameraKit mCameraKit;

    /** Current mode type */
    private @Mode.Type int mCurrentModeType = Mode.Type.SLOW_MOTION_MODE;

    /** Current mode object */
    private Mode mMode;

    /** Mode characteristics */
    private ModeCharacteristics mModeCharacteristics;

    /** Mode config builder */
    private ModeConfig.Builder modeConfigBuilder;

    /** Work thread for time consumed task */
    private HandlerThread mCameraKitThread;

    /** Handler correspond to mCameraKitThread */
    private Handler mCameraKitHandler;

    /** record fps */
    private int recordFps;

    /** mediaRecorder for recording */
    private MediaRecorder mediaRecorder;

    class AutoFitTextureView extends TextureView {
        private int mRatioWidth = 0;

        private int mRatioHeight = 0;

        public AutoFitTextureView(Context context) {
            this(context, null);
        }

        public AutoFitTextureView(Context context, AttributeSet attrs) {
            this(context, attrs, 0);
        }

        public AutoFitTextureView(Context context, AttributeSet attrs, int defStyle) {
            super(context, attrs, defStyle);
        }

        public void setAspectRatio(int width, int height) {
            if ((width < 0) || (height < 0)) {
                throw new IllegalArgumentException("Size cannot be negative.");
            }
            mRatioWidth = width;
            mRatioHeight = height;
            requestLayout();
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int height = MeasureSpec.getSize(heightMeasureSpec);
            if ((0 == mRatioWidth) || (0 == mRatioHeight)) {
                setMeasuredDimension(width, height);
            } else {
                if (width < height * mRatioWidth / mRatioHeight) {
                    setMeasuredDimension(width, width * mRatioHeight / mRatioWidth);
                } else {
                    setMeasuredDimension(height * mRatioWidth / mRatioHeight, height);
                }
            }
        }
    }

    private final TextureView.SurfaceTextureListener mSurfaceTextureListener =
        new TextureView.SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture texture, int width, int height) {
                mCameraKitHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        createMode();
                    }
                });
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture texture, int width, int height) {
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture texture) {
                return true;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture texture) {
            }
        };

    private void createMode() {
        mCameraKit = CameraKit.getInstance(getApplicationContext());
        if (mCameraKit == null) {
            Log.e(TAG, "This device does not support CameraKit！");
        }
        /** Query camera id list */
        String[] cameraLists = mCameraKit.getCameraIdList();
        if ((cameraLists != null) && (cameraLists.length > 0)) {
            Log.i(TAG, "Try to use camera with id " + cameraLists[0]);
            /** Query supported modes of this device */
            int[] modes = mCameraKit.getSupportedModes(cameraLists[0]);
            if (!Arrays.stream(modes).anyMatch((i) -> i == mCurrentModeType)) {
                Log.w(TAG, "Current mode is not supported in this device!");
                return;
            }
            mCameraKit.createMode(cameraLists[0], mCurrentModeType, mModeStateCallback, mCameraKitHandler);
        }
    }

    private void configMode() {
        Log.i(TAG, "configMode begin");
        /** Query supported preview size */
        List<Size> previewSizes = mModeCharacteristics.getSupportedPreviewSizes(SurfaceTexture.class);
        /** Query supported record size */
        Map<Integer, List<Size>> recordSizes = mModeCharacteristics.getSupportedVideoSizes(MediaRecorder.class);
        Log.d(TAG, "configMode: recordSizes = " + recordSizes.size() + ";previewSizes=" + previewSizes.size());

        /** choose 120fps as default */
        recordFps = Metadata.FpsRange.HW_FPS_120;
        mRecordSize = recordSizes.get(Metadata.FpsRange.HW_FPS_120).get(0);
        /** Use the same ratio with preview */
        mPreviewSize = previewSizes.stream()
            .filter(size -> Math.abs((1.0f * size.getHeight() / size.getWidth())
                - (1.0f * mRecordSize.getHeight() / mRecordSize.getWidth())) < 0.01)
            .findFirst()
            .get();
        Log.i(TAG, "configMode: mRecordSize = " + mRecordSize + ";mPreviewSize=" + mPreviewSize);
        /** Update view */
        runOnUiThread(() -> mTextureView.setAspectRatio(mPreviewSize.getHeight(), mPreviewSize.getWidth()));
        SurfaceTexture texture = mTextureView.getSurfaceTexture();
        if (texture == null) {
            Log.e(TAG, "configMode: texture=null!");
            return;
        }
        /** Set buffer size of view */
        texture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
        /** Get surface of texture */
        Surface surface = new Surface(texture);
        /** Add preview and record parameters to config builder */
        modeConfigBuilder.addPreviewSurface(surface).addVideoSize(mRecordSize).setVideoFps(recordFps);
        /** Set callback for config builder */
        modeConfigBuilder.setDataCallback(actionDataCallback, mCameraKitHandler);
        modeConfigBuilder.setStateCallback(actionStateCallback, mCameraKitHandler);
        /** Configure mode */
        mMode.configure();
        Log.i(TAG, "configMode end");
    }

    private void startPreview() {
        mMode.startPreview();
    }

    private void startRecording() {
        mMode.startRecording();
        mediaRecorder.start();
    }

    private void stopRecording() {
        mMode.stopRecording();
        mediaRecorder.stop();
    }

    private final ActionStateCallback actionStateCallback = new ActionStateCallback() {
        @Override
        public void onPreview(Mode mode, int state, PreviewResult result) {
            super.onPreview(mode, state, result);
        }
    };

    private final ActionDataCallback actionDataCallback = new ActionDataCallback() {
        @Override
        public void onThumbnailAvailable(Mode mode, int type, Size size, byte[] data) {
            super.onThumbnailAvailable(mode, type, size, data);
        }
    };

    private final ModeStateCallback mModeStateCallback = new ModeStateCallback() {
        @Override
        public void onCreated(Mode mode) {
            Log.d(TAG, "mModeStateCallback onModeOpened: ");
            mMode = mode;
            mModeCharacteristics = mode.getModeCharacteristics();
            modeConfigBuilder = mMode.getModeConfigBuilder();
            configMode();
        }

        @Override
        public void onCreateFailed(String cameraId, int modeType, int errorCode) {
        }

        @Override
        public void onConfigured(Mode mode) {
            startPreview();
        }

        @Override
        public void onConfigureFailed(Mode mode, int errorCode) {
        }

        @Override
        public void onFatalError(Mode mode, int errorCode) {
        }

        @Override
        public void onReleased(Mode mode) {
        }
    };
}
