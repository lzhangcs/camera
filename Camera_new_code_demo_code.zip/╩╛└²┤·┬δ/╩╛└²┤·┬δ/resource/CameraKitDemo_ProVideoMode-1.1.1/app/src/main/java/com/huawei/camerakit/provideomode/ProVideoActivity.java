/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.provideomode;

import android.content.DialogInterface;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.SurfaceTexture;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.Face;
import android.hardware.camera2.params.RggbChannelVector;
import android.hardware.camera2.params.TonemapCurve;
import android.media.Image;
import android.media.MediaCodec;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Range;
import android.util.Size;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.huawei.camera.camerakit.ActionDataCallback;
import com.huawei.camera.camerakit.ActionStateCallback;
import com.huawei.camera.camerakit.CameraKit;
import com.huawei.camera.camerakit.Metadata;
import com.huawei.camera.camerakit.Mode;
import com.huawei.camera.camerakit.ModeCharacteristics;
import com.huawei.camera.camerakit.ModeConfig;
import com.huawei.camera.camerakit.ModeStateCallback;
import com.huawei.camera.camerakit.RequestKey;
import com.huawei.camera.camerakit.ResultKey;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.stream.Collectors;

/**
 * ProVideoMode界面及设置参数录像的逻辑
 *
 * @since 2019-12-14
 */
public class ProVideoActivity extends AppCompatActivity {
    private static final String TAG = ProVideoActivity.class.getSimpleName();

    private static final @Mode.Type int CURRENT_MODE_TYPE = Mode.Type.PRO_VIDEO_MODE;

    private static final long PREVIEW_SURFACE_READY_TIMEOUT = 5000L;

    private static final Long DEFAULT_CONSTANT_VALUE = 1000000L;

    private static final int CONFIGURATION_VALUE_FOCUS_DISTANCE_MAX = 1000;

    private static final int MAX_SEEKBAR_PROGRESS = 100;

    private static final int OVER_EXPOSURE_STATE = 1;

    private static final int UNDER_EXPOSURE_STATE = 2;

    private static final int VIDEO_FRAME_RATE_30 = 30;

    private static final int FPS_RANGE_PRO_VIDEO_MIN = 12;

    private static final int FPS_RANGE_PRO_VIDEO_30 = 30;

    private static final int FPS_RANGE_PRO_VIDEO_MAX = 60;

    private static final String MF = "MF";

    private static final String NAME_AUTO = "AUTO";

    private static final int VALUE_AUTO = 0;

    private static final double FLOAT_EPSILON = 0.00001;

    private static final float COLOR_CORRECTION_1 = 1f;

    private static final float COLOR_CORRECTION_1_POINT_FIVE = 1.5f;

    private static final float COLOR_CORRECTION_2 = 2f;

    private static final float COLOR_CORRECTION_2_POINT_2 = 2.2f;

    private static final float COLOR_CORRECTION_2_POINT_FIVE = 2.5f;

    private static final float COLOR_CORRECTION_3 = 3f;

    private static final float COLOR_CORRECTION_10 = 10f;

    private static final float COLOR_CORRECTION_20 = 20f;

    private static final float COLOR_CORRECTION_50 = 50f;

    private static final float COLOR_CORRECTION_100 = 100f;

    private static final float COLOR_CORRECTION_255 = 255f;

    private static final float[] CURVE_RED0 = {0.0000f, 0.0000f, 0.0667f, 0.2920f, 0.1333f, 0.4002f, 0.2000f, 0.4812f,
        0.2667f, 0.5484f, 0.3333f, 0.6069f, 0.4000f, 0.6594f, 0.4667f, 0.7072f, 0.5333f, 0.7515f, 0.6000f, 0.7928f,
        0.6667f, 0.8317f, 0.7333f, 0.8685f, 0.8000f, 0.9035f, 0.8667f, 0.9370f, 0.9333f, 0.9691f, 1.0000f, 1.0000f};

    private static final float[] CURVE_GREEN0 = {0.9333f, 0.9691f, 1.0000f, 1.0000f};

    private static final float[] CURVE_BLUE0 = {0.7333f, 0.8685f, 0.8000f, 0.9035f, 0.8667f, 0.9370f};

    private static final float[] CURVE_RED1 = {0.1333f, 0.4002f, 0.2000f, 0.4812f, 1.0000f, 1.0000f};

    private static final float[] CURVE_GREEN1 = {0.6667f, 0.8317f, 0.7333f, 0.8685f, 0.8000f, 0.9035f};

    private static final float[] CURVE_BLUE1 = {0.4002f, 0.2000f, 0.4667f, 0.7072f, 0.5333f, 0.7515f};

    private AutoFitTextureView textureView;

    private Button buttonRecord;

    private Button buttonSnapShot;

    private Button buttonRecordPause;

    private SeekBar mfSeekBar;

    private SeekBar wbSeekBar;

    private TextView mfTextView;

    private TextView wbTextView;

    private HandlerThread backgroundThread;

    private HandlerThread statusCbThread;

    private HandlerThread dataCbThread;

    private HandlerThread modeCbThread;

    private Handler backgroundHandler;

    private Handler statusCbHandler;

    private Handler dataCbHandler;

    private Handler modeCbHandler;

    private CameraKit cameraKit;

    private String cameraId = "0";

    private Mode currentMode;

    private HwRecorder hwRecorder;

    private ModeCharacteristics modeCharacteristics;

    private Size captureSize;

    private Size recordSize;

    private Size previewSize;

    private Surface previewSurface;

    private Surface videoSurface;

    private int orientation;

    private ModeConfig.Builder modeConfigBuilder;

    private OrientationEventListener orientationEventListener;

    private final ConditionVariable previewSurfaceChangedDone = new ConditionVariable();

    /**
     * 对录制过程的操作进行并发控制
     */
    private Semaphore mStartStopRecordLock = new Semaphore(1);

    private CameraKitHelper.RecordState recordState;

    private boolean isRecording;

    private boolean isFirstRecording = true;

    private File file;

    private Rect rect;

    private boolean isInMf;

    private boolean mIsFaceDetected = false;

    // 定义一个软件初始化标识，当初次打开时不执行下发操作
    private boolean initFlag = true;

    private Semaphore prepareModeConfigLock = new Semaphore(1);

    private ModeStateCallback modeStateCallback=new ModeStateCallback(){@Override public void onCreated(Mode mode){Log.d(TAG,"onCreated: mode created "+mode);currentMode=mode;prepareConfig();configureMode();}

    @Override public void onConfigured(Mode mode){currentMode.startPreview();attachModeSettingOperation();}

    @Override public void onReleased(Mode mode){super.onReleased(mode);}};

    private ActionStateCallback actionStateCallback = new ActionStateCallback() {
        @Override
        public void onPreview(Mode mode, int state, PreviewResult result) {
            if (state == PreviewResult.State.PREVIEW_STARTED) {
                Log.i(TAG, "onPreview Started");
            }
        }

        @Override
        public void onTakePicture(Mode mode, int state, TakePictureResult result) {
            switch (state) {
                case TakePictureResult.State.CAPTURE_STARTED:
                    Log.d(TAG, "onState: STATE_CAPTURE_STARTED");
                    break;
                case TakePictureResult.State.CAPTURE_COMPLETED:
                    Log.d(TAG, "onState: STATE_CAPTURE_COMPLETED");
                    showToast("take picture success! file=" + file);
                    runOnUiThread(() -> {
                        buttonSnapShot.setEnabled(true);
                        if (buttonRecordPause.getText().toString().equals("Resume")) {
                            buttonRecord.setEnabled(false);
                        } else {
                            buttonRecord.setEnabled(true);
                        }
                        buttonRecordPause.setEnabled(true);
                    });
                    break;
                default:
                    break;
            }
        }

        @Override
        public void onRecording(Mode mode, int state, RecordingResult result) {
            super.onRecording(mode, state, result);
        }

        @Override
        public void onParameters(Mode mode, @ParametersResult.State int state, ParametersResult result) {
            if (result == null) {
                Log.w(TAG, "onParameter result is null");
                return;
            }
            if (state == ParametersResult.State.ERROR_UNKNOWN) {
                Log.e(TAG, "onParameter ERROR_UNKNOWN");
                return;
            }
            if (result.getResultValue(ResultKey.HW_EXPOSURE_HINT_RESULT) != null) {
                int exposureResult = result.getResultValue(ResultKey.HW_EXPOSURE_HINT_RESULT);
                switch (exposureResult) {
                    case OVER_EXPOSURE_STATE:
                        handleExposureHint("over exposure");
                        break;
                    case UNDER_EXPOSURE_STATE:
                        handleExposureHint("under exposure");
                        break;
                    default:
                        break;
                }
            }
        }

        @Override
        public void onFaceDetection(Mode mode, int state, @Nullable FaceDetectionResult result) {
            Log.e(TAG, "goto the onFaceDetection");
            if (result == null) {
                Log.w(TAG, "onFaceDetection result is null");
                return;
            }
            switch (state) {
                case FaceDetectionResult.State.ERROR_UNKNOWN:
                    Log.e(TAG, "onFaceDetection ERROR_UNKNOWN");
                    break;
                case FaceDetectionResult.State.FACE_DETECTED:
                    handleFaceDetected(result.getFaces());
                    break;
                default:
                    break;
            }

        }
    };

    private void handleFaceDetected(Face[] faces) {
        if (faces == null) {
            Log.w(TAG, "handleFaceDetected is null");
            return;
        }
        boolean isFaceDetected = faces.length > 0;
        String faceInfo = getFaceInfo(faces);
        Log.d(TAG, "Face info: " + faceInfo);
        if (mIsFaceDetected != isFaceDetected) {
            mIsFaceDetected = isFaceDetected;
            Toast.makeText(ProVideoActivity.this, faceInfo, Toast.LENGTH_SHORT).show();
        }
    }

    private String getFaceInfo(Face[] faces) {
        if (faces.length == 0) {
            return "No face detected.";
        }
        StringBuffer stringBuffer = new StringBuffer(0);
        for (Face face : faces) {
            stringBuffer.append(face.toString());
        }
        return stringBuffer.toString();
    }

    private ActionDataCallback actionDataCallback=new ActionDataCallback(){@Override public void onImageAvailable(Mode mode,int type,Image image){super.onImageAvailable(mode,type,image);}};

    private TextureView.SurfaceTextureListener listener=new TextureView.SurfaceTextureListener(){@Override public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture,int i,int i1){backgroundHandler.post(()->cameraKit.createMode(cameraId,CURRENT_MODE_TYPE,modeStateCallback,modeCbHandler));}

    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture,int i,int i1){previewSurfaceChangedDone.open();}

    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture){return true;}

    @Override public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture){}};

    private void startRecording() {
        if (!isRecording) {
            buttonRecord.setText(R.string.stoprecord);
            isRecording = true;
            buttonSnapShot.setEnabled(true);
            buttonRecord.setEnabled(true);
            buttonRecordPause.setVisibility(View.VISIBLE);
            backgroundHandler.post(() -> {
                if (!isFirstRecording) {
                    hwRecorder.prepare(recordSize, videoSurface,
                        CameraKitHelper.getImageRotation(
                            modeCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION), orientation),
                        VIDEO_FRAME_RATE_30);
                }
                isFirstRecording = false;
                currentMode.startRecording();
                hwRecorder.start();
            });
        } else {
            buttonSnapShot.setEnabled(false);
            buttonRecord.setText(R.string.record);
            isRecording = false;
            buttonRecordPause.setVisibility(View.INVISIBLE);
            backgroundHandler.post(() -> {
                currentMode.stopRecording();
                hwRecorder.stop();
            });
            showToast(CameraKitHelper.getCurrentVideoFileName() + " saved");
        }
    }

    private void handleExposureHint(String msg) {
        if (msg == null) {
            Log.w(TAG, "handleExposureHint is null");
            return;
        }
        showToast(msg);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        orientationEventListener = new OrientationEventListener(this, SensorManager.SENSOR_DELAY_NORMAL) {
            @Override
            public void onOrientationChanged(int orientation) {
                ProVideoActivity.this.orientation = orientation;
            }
        };
        if (orientationEventListener.canDetectOrientation()) {
            orientationEventListener.enable();
            Log.d(TAG, "onCreate: mOrientationEventListener enabled.");
        } else {
            orientationEventListener.disable();
            Log.d(TAG, "onCreate: mOrientationEventListener cannot detect Orientation.");
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        startBackgroundThreads();
    }

    private void showToast(final String text) {
        runOnUiThread(() -> {
            Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();
        });
    }

    private void initViews() {
        textureView = findViewById(R.id.texture);
        buttonRecord = findViewById(R.id.record);
        buttonSnapShot = findViewById(R.id.snap_shot);
        buttonRecordPause = findViewById(R.id.recordPause);
        mfSeekBar = findViewById(R.id.mfSeekbar);
        wbSeekBar = findViewById(R.id.wbSeekbar);
        mfTextView = findViewById(R.id.mfTips);
        wbTextView = findViewById(R.id.wbTips);
        buttonRecord.setOnClickListener(view -> startRecording());
        buttonSnapShot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonRecordPause.setEnabled(false);
                buttonSnapShot.setEnabled(false);
                buttonRecord.setEnabled(false);
                captureFile();
            }
        });
        buttonSnapShot.setEnabled(false);
        buttonRecordPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (buttonRecordPause.getText().toString().equals("Pause")) {
                    buttonRecordPause.setText("Resume");
                    buttonRecord.setEnabled(false);
                    pauseRecord();
                } else {
                    buttonRecordPause.setText("Pause");
                    buttonRecord.setEnabled(true);
                    resumeRecord();
                }
            }
        });
    }

    private void pauseRecord() {
        if (recordState == CameraKitHelper.RecordState.RECORDING) {
            try {
                mStartStopRecordLock.acquire();
                currentMode.pauseRecording();
                hwRecorder.pause();
                recordState = CameraKitHelper.RecordState.PAUSED;
            } catch (InterruptedException ex) {
                Log.e(TAG, "acquiremStartStopRecordLock pauseRecord failed");
            } catch (IllegalStateException e) {
                Log.e(TAG, "camerakit pause error " + e.getCause());
            } finally {
                mStartStopRecordLock.release();
            }
        }
    }

    private void resumeRecord() {
        try {
            mStartStopRecordLock.acquire();
            currentMode.resumeRecording();
            hwRecorder.resume();
            recordState = CameraKitHelper.RecordState.RECORDING;
        } catch (InterruptedException e) {
            Log.e(TAG, "acquiremStartStopRecordLock resumeRecord failed");
        } catch (IllegalStateException e) {
            Log.e(TAG, "camerakit resume error " + e.getCause());
        } finally {
            mStartStopRecordLock.release();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        initHandlers();
        buttonRecord.setText(R.string.record);
        if (!PermissionHelper.hasPermission(this)) {
            PermissionHelper.requestPermission(this);
            return;
        } else {
            CameraKitHelper.initStoreDir(getApplicationContext());
            CameraKitHelper.checkImageDirectoryExists();
            if (!initCameraKit()) {
                showAlertWarning(getString(R.string.warning_str));
                return;
            }
        }
        if (!Arrays.stream(cameraKit.getSupportedModes(cameraId)).boxed().collect(Collectors.toList()).contains(
                CURRENT_MODE_TYPE)) {
            showAlertWarning(getString(R.string.mode_not_support));
            return;
        }
        hwRecorder = new HwRecorder();
        if (textureView.isAvailable()) {
            Log.d(TAG, "onResume: textureView is available");
            backgroundHandler
                .post(() -> cameraKit.createMode(cameraId, CURRENT_MODE_TYPE, modeStateCallback, modeCbHandler));
        }
        textureView.setSurfaceTextureListener(listener);
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause: ");
        if (currentMode != null) {
            currentMode.release();
            currentMode = null;
        }
        if (hwRecorder != null) {
            hwRecorder.clearInvalidFile();
            hwRecorder.release();
            hwRecorder = null;
        }
        super.onPause();
    }

    private boolean initCameraKit() {
        cameraKit = CameraKit.getInstance(getApplicationContext());
        if (cameraKit == null) {
            Log.e(TAG, "initCamerakit: this devices not support camerakit or not installed!");
            return false;
        }
        return true;
    }

    private void showAlertWarning(String msg) {
        new AlertDialog.Builder(this).setMessage(msg)
                .setTitle("warning:")
                .setCancelable(false)
                .setPositiveButton(R.string.ok_str, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .show();
    }

    private void captureFile() {
        try {
            Log.d(TAG, "captureFile: start " + String.format(Locale.ENGLISH, CameraKitHelper.MODE_DEFAULT_PRINT,
                currentMode.getCameraId(), currentMode.getType()));
            file = CameraKitHelper.setFileName(currentMode.getType(), "file");
            currentMode.setImageRotation(CameraKitHelper
                .getImageRotation(modeCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION), orientation));
            currentMode.takePicture(file);
            Log.d(TAG, "captureFile end");
        } catch (IllegalStateException ex) {
            Log.e(TAG, "capture file end " + ex.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopBackgroundThreads();
        if (orientationEventListener != null) {
            orientationEventListener.disable();
        }
    }

    private void startBackgroundThreads() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        Log.d(TAG, "startBackgroundThreads: CameraBackground threadId = " + backgroundThread.getThreadId());
        statusCbThread = new HandlerThread("statusCB");
        statusCbThread.start();
        Log.d(TAG, "startBackgroundThreads: statusCB threadId = " + statusCbThread.getThreadId());
        dataCbThread = new HandlerThread("dataCB");
        dataCbThread.start();
        Log.d(TAG, "startBackgroundThreads: dataCB threadId = " + dataCbThread.getThreadId());
        modeCbThread = new HandlerThread("ModeCB");
        modeCbThread.start();
        Log.d(TAG, "startBackgroundThreads: ModeCB threadId = " + modeCbThread.getThreadId());
    }

    private void initHandlers() {
        Log.d(TAG, "initHandlers");
        backgroundHandler = new Handler(backgroundThread.getLooper());
        statusCbHandler = new Handler(statusCbThread.getLooper());
        dataCbHandler = new Handler(dataCbThread.getLooper());
        modeCbHandler = new Handler(modeCbThread.getLooper());
    }

    private void stopBackgroundThreads() {
        Log.d(TAG, "stopBackgroundThread: ");
        stopCameraBackgroundThread();
        stopDataCbThread();
        stopStatusCbThread();
        stopModeCbThread();
    }

    private void stopCameraBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop backgroundThread " + e.getMessage());
            }
        }
    }

    private void stopStatusCbThread() {
        if (statusCbThread != null) {
            statusCbThread.quitSafely();
            try {
                statusCbThread.join();
                statusCbThread = null;
                statusCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop statusCbThread " + e.getMessage());
            }
        }
    }

    private void stopDataCbThread() {
        if (dataCbThread != null) {
            dataCbThread.quitSafely();
            try {
                dataCbThread.join();
                dataCbThread = null;
                dataCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop dataCbThread " + e.getMessage());
            }
        }
    }

    private void stopModeCbThread() {
        if (modeCbThread != null) {
            modeCbThread.quitSafely();
            try {
                modeCbThread.join();
                modeCbThread = null;
                modeCbHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "InterruptedException in stop dataCbThread " + e.getMessage());
            }
        }
    }

    private void prepareConfig() {
        try {
            prepareModeConfigLock.acquire();
            modeCharacteristics = cameraKit.getModeCharacteristics(cameraId, CURRENT_MODE_TYPE);
            Log.d(TAG, "activePreview: "
                + String.format(Locale.ENGLISH, CameraKitHelper.MODE_DEFAULT_PRINT, cameraId, CURRENT_MODE_TYPE));
            List<Size> previewSizes = modeCharacteristics.getSupportedPreviewSizes(SurfaceTexture.class);
            List<Size> captureSizes = modeCharacteristics.getSupportedCaptureSizes(ImageFormat.JPEG);
            List<Size> recordSizes = getSupportedVideoSizes();
            if (previewSizes != null) {
                Log.d(TAG, "activePreview: previewSizes = " + previewSizes);
            }
            if (captureSizes != null) {
                Log.d(TAG, "activePreview: captureSizes = " + Arrays.toString(captureSizes.toArray()));
            }
            if (recordSizes != null) {
                Log.d(TAG, "activePreview: recordSizes = " + recordSizes);
            }
            // choose one pair of Record Resolution as a demo
            preparePreviewSurface(previewSizes, captureSizes, recordSizes);
            prepareVideoSurface();
        } catch (InterruptedException e) {
            Log.e(TAG, "prepareModeConfig fail " + e.getMessage());
        } finally {
            prepareModeConfigLock.release();
        }
    }

    private List<Size> getSupportedVideoSizes() {
        Map<Integer, List<Size>> videoSizes = modeCharacteristics.getSupportedVideoSizes(MediaRecorder.class);
        Log.d(TAG, "getSupportedVideoSizes: videoSizes" + videoSizes);
        if (videoSizes == null) {
            return new ArrayList<>(0);
        }
        if (videoSizes.containsKey(Metadata.FpsRange.HW_FPS_30)) {
            return videoSizes.get(Metadata.FpsRange.HW_FPS_30);
        }
        return new ArrayList<>(0);
    }

    private void preparePreviewSurface(List<Size> previewSizes, List<Size> captureSizes, List<Size> recordSizes) {
        if (!CameraKitHelper.isEmptyCollection(recordSizes)) {
            recordSize = Collections.max(recordSizes, new CameraKitHelper.CompareSizesByArea());
            captureSize = CameraKitHelper.getSnapShotSize(recordSize, captureSizes);
            Size previewSizeNeeded = CameraKitHelper.getOptimalVideoPreviewSize(this, recordSize, previewSizes);
            Log.d(TAG, "preparePreviewSurface: previewSize = " + previewSizeNeeded);
            waitTextureViewSizeUpdate(previewSizeNeeded);
            SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
            if (surfaceTexture == null) {
                Log.e(TAG, "preparePreviewSurface: surfaceTexture is null");
            }
            surfaceTexture.setDefaultBufferSize(previewSize.getWidth(), previewSize.getHeight());
            previewSurface = new Surface(surfaceTexture);
        }
    }

    private void prepareVideoSurface() {
        if ((recordSize != null) && (hwRecorder != null)) {
            videoSurface = MediaCodec.createPersistentInputSurface();
            hwRecorder.prepare(
                recordSize, videoSurface, CameraKitHelper
                    .getImageRotation(modeCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION), orientation),
                VIDEO_FRAME_RATE_30);
            isFirstRecording = true;
        }
    }

    private void configureMode() {
        modeConfigBuilder = currentMode.getModeConfigBuilder();
        modeConfigBuilder.setStateCallback(actionStateCallback, statusCbHandler);
        modeConfigBuilder.setDataCallback(actionDataCallback, dataCbHandler);
        try {
            prepareModeConfigLock.acquire();
            modeConfigBuilder.addCaptureImage(captureSize, ImageFormat.JPEG);
            if (videoSurface != null) {
                modeConfigBuilder.addVideoSurface(videoSurface);
            }
            modeConfigBuilder.addPreviewSurface(previewSurface);
            currentMode.configure();
        } catch (InterruptedException e) {
            Log.e(TAG, "configureMode: " + e.getMessage());
        } finally {
            prepareModeConfigLock.release();
        }
    }

    private void refreshTextureView(int height, int width) {
        ConditionVariable conditionVariable = new ConditionVariable();
        conditionVariable.close();
        runOnUiThread(() -> {
            textureView.setAspectRatio(height, width);
            conditionVariable.open();
        });
        conditionVariable.block();
    }

    /**
     * wait for textureView updated
     *
     * @param targetPreviewSize preview size
     */
    private void waitTextureViewSizeUpdate(Size targetPreviewSize) {
        refreshTextureView(targetPreviewSize.getHeight(), targetPreviewSize.getWidth());
        if (previewSize == null) {
            Log.d(TAG, "mPreviewSize is null");
            previewSize = targetPreviewSize;
            previewSurfaceChangedDone.close();
            previewSurfaceChangedDone.block(PREVIEW_SURFACE_READY_TIMEOUT);
        } else {
            if (targetPreviewSize.getHeight() * previewSize.getWidth()
                - targetPreviewSize.getWidth() * previewSize.getHeight() == 0) {
                Log.d(TAG, "mPreviewSize ratio not change");
                previewSize = targetPreviewSize;
            } else {
                Log.d(TAG, "mPreviewSize changed");
                previewSize = targetPreviewSize;
                previewSurfaceChangedDone.close();
                previewSurfaceChangedDone.block(PREVIEW_SURFACE_READY_TIMEOUT);
            }
        }
    }

    private void attachModeSettingOperation() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                initMeteringSpinner();
                initProIsoSpinner();
                initProEvSpinner();
                initProAfSpinner();
                initMfSeekerBar();
                initProAwbSpinner();
                initWbSeekerBar();
                initExposureHintSpinner();
                initControlFaceDetectModeSpinner();
                initColorCorrectGainSpinner();
                initColorCorrectionSpinner();
                initAeLockSpinner();
                initAwbLockSpinner();
                initTargetFpsSpinner();
                initTonemapCurveSpinner();
                initNoiseReductionSpinner();
                initEdgeSpinner();
                iniTonemapModeSpinner();
            }
        });
    }

    private void initMeteringSpinner() {
        final Spinner meteringSpinner = findViewById(R.id.metering);
        meteringSpinner.setVisibility(View.VISIBLE);
        List<Byte> meteringList = modeCharacteristics.getParameterRange(RequestKey.HW_PRO_METERING_VALUE);
        Map<String, Byte> showMap = new HashMap<>();
        for (byte metering : meteringList) {
            switch (metering) {
                case 0:
                    showMap.put("矩阵测光", metering);
                    break;
                case 2:
                    showMap.put("中央重点测光", metering);
                    break;
                case 3:
                    showMap.put("点测光", metering);
                    break;
                default:
                    break;
            }
        }
        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        meteringSpinner.setAdapter(adapter);
        meteringSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = meteringSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(RequestKey.HW_PRO_METERING_VALUE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void initProIsoSpinner() {
        final Spinner isoSpinner = findViewById(R.id.iso);
        isoSpinner.setVisibility(View.VISIBLE);
        List<Integer> isoList = modeCharacteristics.getParameterRange(RequestKey.HW_PRO_SENSOR_ISO_VALUE);
        List<String> showList = new ArrayList<>();
        for (int index = 0; index < isoList.size(); index++) {
            if (isoList.get(index) == VALUE_AUTO) {
                showList.add(NAME_AUTO);
                continue;
            }
            showList.add(String.valueOf(isoList.get(index)));
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item, R.id.itemText, showList);
        isoSpinner.setAdapter(adapter);
        isoSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = isoSpinner.getItemAtPosition(position).toString();
                if (NAME_AUTO.equals(text)) {
                    currentMode.setParameter(RequestKey.HW_PRO_SENSOR_ISO_VALUE, VALUE_AUTO);
                } else {
                    currentMode.setParameter(RequestKey.HW_PRO_SENSOR_ISO_VALUE, Integer.parseInt(text));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void initProEvSpinner() {
        final Spinner evSpinner = findViewById(R.id.ev);
        evSpinner.setVisibility(View.VISIBLE);
        List<Float> evList = modeCharacteristics.getParameterRange(RequestKey.HW_EXPOSURE_COMPENSATION_VALUE);
        List<String> showList = new ArrayList<>();
        if (evList.contains(0.0f)) {
            showList.add(String.valueOf(VALUE_AUTO));
        }
        for (Float evValue : evList) {
            if (Math.abs(evValue - 0.0f) < FLOAT_EPSILON) {
                continue;
            }
            showList.add(String.valueOf(evValue));
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item, R.id.itemText, showList);
        evSpinner.setAdapter(adapter);
        evSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = evSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(RequestKey.HW_EXPOSURE_COMPENSATION_VALUE, Float.parseFloat((String) text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void initProAwbSpinner() {
        final Spinner awbSpinner = findViewById(R.id.awb);
        awbSpinner.setVisibility(View.VISIBLE);
        List<Integer> awbList = modeCharacteristics.getParameterRange(RequestKey.HW_PRO_AWB_TYPE);
        Map<String, Integer> showMap = new HashMap<>();
        for (Integer awbValue : awbList) {
            switch (awbValue) {
                case 1:
                    showMap.put("AWB", awbValue);
                    break;
                case 6:
                    showMap.put("阴天", awbValue);
                    break;
                case 3:
                    showMap.put("荧光灯", awbValue);
                    break;
                case 2:
                    showMap.put("白炽灯", awbValue);
                    break;
                case 5:
                    showMap.put("晴天", awbValue);
                    break;
                case 0:
                    showMap.put("自定义", awbValue);
                    break;
                default:
                    break;
            }
        }
        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        awbSpinner.setAdapter(adapter);
        awbSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = awbSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(RequestKey.HW_PRO_AWB_TYPE, showMap.get(text));
                if ("自定义".equals(text)) {
                    wbSeekBar.setVisibility(View.VISIBLE);
                    wbTextView.setVisibility(View.VISIBLE);
                } else {
                    wbSeekBar.setVisibility(View.INVISIBLE);
                    wbTextView.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void initProAfSpinner() {
        final Spinner afSpinner = findViewById(R.id.af);
        afSpinner.setVisibility(View.VISIBLE);
        int[] afArray = modeCharacteristics.getSupportedAutoFocus();
        Map<String, Byte> showMap = new HashMap<>();
        for (int afValue : afArray) {
            switch (afValue) {
                case Metadata.FocusMode.HW_AF_CONTINUOUS:
                    showMap.put("AF-C", Metadata.FocusMode.HW_AF_CONTINUOUS);
                    break;
                case Metadata.FocusMode.HW_AF_TOUCH_LOCK:
                    showMap.put("AF-S", Metadata.FocusMode.HW_AF_TOUCH_LOCK);
                    break;
                case Metadata.FocusMode.HW_AF_OFF:
                    showMap.put(MF, Metadata.FocusMode.HW_AF_OFF);
                    break;
                default:
                    break;
            }
        }
        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        afSpinner.setAdapter(adapter);
        afSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = afSpinner.getItemAtPosition(position).toString();
                if (MF.equals(text)) {
                    isInMf = true;
                    mfSeekBar.setVisibility(View.VISIBLE);
                    mfTextView.setVisibility(View.VISIBLE);
                } else {
                    isInMf = false;
                    mfSeekBar.setVisibility(View.INVISIBLE);
                    mfTextView.setVisibility(View.INVISIBLE);
                }
                proAfAction(text, rect);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void proAfAction(String text, Object value) {
        switch (text) {
            case "AF-C":
                if (!(value instanceof Rect)) {
                    return;
                }
                currentMode.setFocus(Metadata.FocusMode.HW_AF_CONTINUOUS, (Rect) value);
                break;
            case "AF-S":
                if (!(value instanceof Rect)) {
                    return;
                }
                currentMode.setFocus(Metadata.FocusMode.HW_AF_TOUCH_LOCK, (Rect) value);
                break;
            case MF:
                currentMode.setFocus(Metadata.FocusMode.HW_AF_OFF, null);
                break;
            default:
                break;
        }
    }

    private void initMfSeekerBar() {
        List<Float> mfList = modeCharacteristics.getParameterRange(RequestKey.HW_PRO_FOCUS_DISTANCE_VALUE);
        float mfValue = mfList.get(0);
        mfSeekBar.setMax(CONFIGURATION_VALUE_FOCUS_DISTANCE_MAX);
        mfSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean isFromUser) {
                if (progress > 0) {
                    Float realValue = Float.parseFloat(String.valueOf(progress));
                    mfTextView.setText("Mf Rangs: " + mfValue + "-" + CONFIGURATION_VALUE_FOCUS_DISTANCE_MAX);
                    currentMode.setParameter(RequestKey.HW_PRO_FOCUS_DISTANCE_VALUE, realValue);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void initWbSeekerBar() {
        List<Integer> wbList = modeCharacteristics.getParameterRange(RequestKey.HW_PRO_MANUAL_WB_VALUE);
        if ((wbList == null) || (wbList.size() == 0) || !(wbList.get(0) instanceof Integer)) {
            return;
        }
        wbSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean isFromUser) {
                Integer[] ranges = new Integer[wbList.size()];
                wbList.toArray(ranges);
                int index = Math.round((1.0f * progress / MAX_SEEKBAR_PROGRESS) * (ranges[1] - ranges[0]));
                int realValue = ranges[0] + index;
                wbTextView.setText("Wb Value: " + realValue + "/" + ranges[1]);
                currentMode.setParameter(RequestKey.HW_PRO_MANUAL_WB_VALUE, realValue);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void initExposureHintSpinner() {
        final Spinner hintSpinner = findViewById(R.id.exposureHintSpinner);
        hintSpinner.setVisibility(View.VISIBLE);
        boolean isHintSupported =
            CameraKitHelper.contains(modeCharacteristics.getSupportedParameters(), RequestKey.HW_PRO_EXPOSURE_HINT);
        List<String> list = booleanToList(isHintSupported, R.string.hintOn, R.string.hintOff);
        if (list.size() == 0) {
            hintSpinner.setVisibility(View.GONE);
            return;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item, R.id.itemText, list);
        hintSpinner.setAdapter(adapter);
        hintSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = hintSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(RequestKey.HW_PRO_EXPOSURE_HINT, "HintOn".equals(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private List<String> booleanToList(boolean isSupport, int offId, int onId) {
        List<String> lists = new ArrayList<>(0);
        if (isSupport) {
            lists.add(getString(offId));
            lists.add(getString(onId));
        }
        return lists;
    }

    /**
     * 原生相机能力增强：android.statistics.faceDetectMode
     */
    private void initControlFaceDetectModeSpinner() {
        final Spinner faceDetectedModeSpinner = findViewById(R.id.controlFaceDetectModeSpinner);
        faceDetectedModeSpinner.setVisibility(View.VISIBLE);
        List<Integer> faceDetecedModeList =
            modeCharacteristics.getParameterRange(CaptureRequest.STATISTICS_FACE_DETECT_MODE);
        Map<String, Integer> showMap = new HashMap<>();
        for (int faceDeteced : faceDetecedModeList) {
            switch (faceDeteced) {
                case 0:
                    showMap.put("面部检测_OFF", faceDeteced);
                    break;
                case 1:
                    showMap.put("面部检测_SIMPLE", faceDeteced);
                    break;
                case 2:
                    showMap.put("面部检测_FULL", faceDeteced);
                    break;
                default:
                    break;
            }
        }
        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        faceDetectedModeSpinner.setAdapter(adapter);
        faceDetectedModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = faceDetectedModeSpinner.getItemAtPosition(position).toString();
                // 需使用华为相机tag，开启人脸检测
                currentMode.setFaceDetection(Metadata.FaceDetectionType.HW_FACE_DETECTION, true);
                currentMode.setParameter(CaptureRequest.STATISTICS_FACE_DETECT_MODE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.colorCorrection.gains
     */
    private void initColorCorrectGainSpinner() {
        final Spinner colorGainSpinner = findViewById(R.id.colorGainSpinner);
        colorGainSpinner.setVisibility(View.VISIBLE);
        Map<String, RggbChannelVector> showMap = new HashMap<>();
        // 该tag需要自定义下发值，列举几列
        showMap.put("色差校正增益_(2.2,2.2,2.2,2.2)", new RggbChannelVector(COLOR_CORRECTION_2_POINT_2,
            COLOR_CORRECTION_2_POINT_2, COLOR_CORRECTION_2_POINT_2, COLOR_CORRECTION_2_POINT_2));
        showMap.put("色差校正增益_(1,2.5,1.5,2)", new RggbChannelVector(COLOR_CORRECTION_1, COLOR_CORRECTION_2_POINT_FIVE,
            COLOR_CORRECTION_1_POINT_FIVE, COLOR_CORRECTION_2));
        showMap.put("色差校正增益_(1,2,3,3)",
            new RggbChannelVector(COLOR_CORRECTION_1, COLOR_CORRECTION_2, COLOR_CORRECTION_3, COLOR_CORRECTION_3));
        showMap.put("色差校正增益_(10,20,50,100)",
            new RggbChannelVector(COLOR_CORRECTION_10, COLOR_CORRECTION_20, COLOR_CORRECTION_50, COLOR_CORRECTION_100));
        showMap.put("色差校正增益_(255,255,255,255)", new RggbChannelVector(COLOR_CORRECTION_255, COLOR_CORRECTION_255,
            COLOR_CORRECTION_255, COLOR_CORRECTION_255));

        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        colorGainSpinner.setAdapter(adapter);
        colorGainSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 使该能力在软件第一次打开时，不执行操作
                if (initFlag) {
                    initFlag = false;
                } else {
                    String text = colorGainSpinner.getItemAtPosition(position).toString();
                    currentMode.setParameter(CaptureRequest.COLOR_CORRECTION_GAINS, showMap.get(text));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.colorCorrection.mode
     */
    private void initColorCorrectionSpinner() {
        final Spinner colorCorrectionModeSpinner = findViewById(R.id.colorCorrectionSpinner);
        colorCorrectionModeSpinner.setVisibility(View.VISIBLE);
        Map<String, Integer> showMap = new HashMap<>();
        // 该tag需要自定义下发值，列举几列
        showMap.put("色差校正模式_TRANSFORM_MATRIX", CameraMetadata.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX);
        showMap.put("色差校正模式_FAST ", CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_FAST);
        showMap.put("色差校正模式_HIGH_QUALITY ", CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY);

        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        colorCorrectionModeSpinner.setAdapter(adapter);
        colorCorrectionModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = colorCorrectionModeSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.COLOR_CORRECTION_MODE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.control.aeLock
     */
    private void initAeLockSpinner() {
        final Spinner aeLockSpinner = findViewById(R.id.aeLockSpinner);
        aeLockSpinner.setVisibility(View.VISIBLE);
        boolean isHintSupported =
            CameraKitHelper.contains(modeCharacteristics.getSupportedParameters(), CaptureRequest.CONTROL_AE_LOCK);
        List<String> list = booleanToList(isHintSupported, R.string.aeLockOff, R.string.aeLockOn);
        if (list.size() == 0) {
            aeLockSpinner.setVisibility(View.GONE);
            return;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item, R.id.itemText, list);
        aeLockSpinner.setAdapter(adapter);
        aeLockSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = aeLockSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.CONTROL_AE_LOCK, "aeLockOn".equals(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.control.awbLock
     */
    private void initAwbLockSpinner() {
        final Spinner awbLockSpinner = findViewById(R.id.awbLockSpinner);
        awbLockSpinner.setVisibility(View.VISIBLE);
        boolean isHintSupported =
            CameraKitHelper.contains(modeCharacteristics.getSupportedParameters(), CaptureRequest.CONTROL_AWB_LOCK);
        List<String> list = booleanToList(isHintSupported, R.string.awbLockOff, R.string.awbLockOn);
        if (list.size() == 0) {
            awbLockSpinner.setVisibility(View.GONE);
            return;
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item, R.id.itemText, list);
        awbLockSpinner.setAdapter(adapter);
        awbLockSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = awbLockSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.CONTROL_AWB_LOCK, "awbLockOn".equals(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.control.aeTargetFpsRange
     */
    private void initTargetFpsSpinner() {
        final Spinner targetFpsSpinner = findViewById(R.id.controlAeFpsSpinner);
        targetFpsSpinner.setVisibility(View.VISIBLE);
        List<Range<Integer>> targetFpsList =
            modeCharacteristics.getParameterRange(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE);
        Map<String, Range> showMap = new HashMap<>();
        showMap.clear();
        boolean isFpsMoreThanThirty = false;
        for (Range<Integer> targetFps : targetFpsList) {
            if ((targetFps.getUpper()) > FPS_RANGE_PRO_VIDEO_30) {
                isFpsMoreThanThirty = true;
            }
            String key = "帧率:" + targetFps.getLower() + "," + targetFps.getUpper();
            showMap.put(key, targetFps);
        }
        // 专业录像模式中除了设备上报的能力值外，还可以使用12至30的固定帧率
        for (int i = FPS_RANGE_PRO_VIDEO_MIN; i <= FPS_RANGE_PRO_VIDEO_30; i++) {
            String key = "帧率:" + i + "," + i;
            if (!showMap.containsKey(key)) {
                showMap.put(key, new Range(i, i));
            }
        }

        // 上报的能力值若有FPS大于30的情况，则可以使用30至60的固定帧率
        if (isFpsMoreThanThirty) {
            for (int i = FPS_RANGE_PRO_VIDEO_30 + 1; i <= FPS_RANGE_PRO_VIDEO_MAX; i++) {
                String key = "帧率:" + i + "," + i;
                if (!showMap.containsKey(key)) {
                    showMap.put(key, new Range(i, i));
                }
            }
        }
        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        targetFpsSpinner.setAdapter(adapter);
        targetFpsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = targetFpsSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.tonemap.curve
     */
    private void initTonemapCurveSpinner() {
        final Spinner tonemapCurveSpinner = findViewById(R.id.tonemapCurveSpinner);
        tonemapCurveSpinner.setVisibility(View.VISIBLE);
        Map<String, TonemapCurve> showMap = new HashMap<>();
        showMap.put("red0, green0, blue0", new TonemapCurve(CURVE_RED0, CURVE_GREEN0, CURVE_BLUE0));
        showMap.put("red1, green1, blue1", new TonemapCurve(CURVE_RED1, CURVE_GREEN1, CURVE_BLUE1));

        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        tonemapCurveSpinner.setAdapter(adapter);
        tonemapCurveSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = tonemapCurveSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.TONEMAP_CURVE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.noiseReduction.mode
     */
    private void initNoiseReductionSpinner() {
        final Spinner noiseReductionSpinner = findViewById(R.id.noiseReductionSpinner);
        noiseReductionSpinner.setVisibility(View.VISIBLE);
        List<Integer> noiseReductionModeList =
            modeCharacteristics.getParameterRange(CaptureRequest.NOISE_REDUCTION_MODE);
        Map<String, Integer> showMap = new HashMap<>();
        for (int noiseReduction : noiseReductionModeList) {
            switch (noiseReduction) {
                case 0:
                    showMap.put("降噪_OFF", CameraMetadata.NOISE_REDUCTION_MODE_OFF);
                    break;
                case 1:
                    showMap.put("降噪_FAST", CameraMetadata.NOISE_REDUCTION_MODE_FAST);
                    break;
                case 2:
                    showMap.put("降噪_HIGH_QUALITY", CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY);
                    break;
                case 3:
                    showMap.put("降噪_MINIMAL", CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL);
                    break;
                case 4:
                    showMap.put("降噪_ZERO_SHUTTER_LAG", CameraMetadata.NOISE_REDUCTION_MODE_ZERO_SHUTTER_LAG);
                    break;
                default:
                    break;
            }
        }

        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        noiseReductionSpinner.setAdapter(adapter);
        noiseReductionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = noiseReductionSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.NOISE_REDUCTION_MODE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.edge.mode
     */
    private void initEdgeSpinner() {
        final Spinner edgeSpinner = findViewById(R.id.edgeSpinner);
        edgeSpinner.setVisibility(View.VISIBLE);
        List<Integer> edgeModeList = modeCharacteristics.getParameterRange(CaptureRequest.EDGE_MODE);
        Map<String, Integer> showMap = new HashMap<>();
        for (int edgeMode : edgeModeList) {
            switch (edgeMode) {
                case 0:
                    showMap.put("锐化_OFF", CameraMetadata.EDGE_MODE_OFF);
                    break;
                case 1:
                    showMap.put("锐化_FAST", CameraMetadata.EDGE_MODE_FAST);
                    break;
                case 2:
                    showMap.put("锐化_HIGH_QUALITY", CameraMetadata.EDGE_MODE_HIGH_QUALITY);
                    break;
                case 3:
                    showMap.put("锐化_ZERO_SHUTTER_LAG", CameraMetadata.EDGE_MODE_ZERO_SHUTTER_LAG);
                    break;
                default:
                    break;
            }
        }

        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        edgeSpinner.setAdapter(adapter);
        edgeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = edgeSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.EDGE_MODE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    /**
     * 原生相机能力增强：android.tonemap.mode
     */
    private void iniTonemapModeSpinner() {
        final Spinner tonemapModeSpinner = findViewById(R.id.tonemapModeSpinner);
        tonemapModeSpinner.setVisibility(View.VISIBLE);
        List<Integer> tonemapModeList = modeCharacteristics.getParameterRange(CaptureRequest.TONEMAP_MODE);
        Map<String, Integer> showMap = new HashMap<>();
        for (int tonemapMode : tonemapModeList) {
            switch (tonemapMode) {
                case 0:
                    showMap.put("映射模式_CONTRAST_CURVE", CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE);
                    break;
                case 1:
                    showMap.put("映射模式_FAST", CameraMetadata.TONEMAP_MODE_FAST);
                    break;
                case 2:
                    showMap.put("映射模式_HIGH_QUALITY", CameraMetadata.TONEMAP_MODE_HIGH_QUALITY);
                    break;
                case 3:
                    showMap.put("映射模式_GAMMA_VALUE", CameraMetadata.TONEMAP_MODE_GAMMA_VALUE);
                    break;
                case 4:
                    showMap.put("映射模式_PRESET_CURVE", CameraMetadata.TONEMAP_MODE_PRESET_CURVE);
                    break;
                default:
                    break;
            }
        }

        ArrayAdapter<String> adapter =
            new ArrayAdapter<>(this, R.layout.item, R.id.itemText, new ArrayList<>(showMap.keySet()));
        tonemapModeSpinner.setAdapter(adapter);
        tonemapModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String text = tonemapModeSpinner.getItemAtPosition(position).toString();
                currentMode.setParameter(CaptureRequest.TONEMAP_MODE, showMap.get(text));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }
}
