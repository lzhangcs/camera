/*
 * Copyright 2017 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.huawei.camerakit.provideomode;

import android.content.Context;
import android.graphics.Point;
import android.hardware.camera2.CaptureRequest;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;

import com.huawei.camera.camerakit.Mode;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * CameraKit tools functions
 */
public class CameraKitHelper {
    /**
     * screen orientations
     */
    public static final SparseIntArray ORIENTATIONS = new SparseIntArray();

    /**
     * 分辨率差异容忍门限
     */
    public static final float FLOAT_COMPARISON_TOLERANCE = 0.01f;

    /**
     * log format
     */
    public static final String MODE_DEFAULT_PRINT = "mCurrentCameraId = %s; mCurrentModeType = %d";

    private static final String CONSTANT_RAW = "raw";

    private static final Size RECORD_SOLUTION_4K = new Size(3840, 2160);

    private static final String TAG = CameraKitHelper.class.getSimpleName();

    private static final int ROTATION_DEGREE_0 = 0;

    private static final int ROTATION_DEGREE_90 = 90;

    private static final int ROTATION_DEGREE_180 = 180;

    private static final int ROTATION_DEGREE_270 = 270;

    private static final int ROTATION_DEGREE_360 = 360;

    private static final int ROTATION_DEGREE_30 = 30;

    private static final double RATIO_TOLERANCE = 0.05;

    private static final int MAX_RESOLUTION_VALUE = 65536;

    private static String videoFilePath;

    /**
     * dirs for file to be saved
     */
    private static String imageSaveDir = "";

    static {
        ORIENTATIONS.append(Surface.ROTATION_0, ROTATION_DEGREE_90);
        ORIENTATIONS.append(Surface.ROTATION_90, ROTATION_DEGREE_0);
        ORIENTATIONS.append(Surface.ROTATION_180, ROTATION_DEGREE_270);
        ORIENTATIONS.append(Surface.ROTATION_270, ROTATION_DEGREE_180);
    }

    /**
     * 录像状态，空闲，录制准备，录制中，暂停
     *
     * @since 2019-06-06
     */
    public enum RecordState {
        /**
         * 空闲状态
         */
        IDLE,
        /**
         * 录制准备状态
         */
        PRE_PROCESS,
        /**
         * 录制中状态
         */
        RECORDING,
        /**
         * 录制暂停状态
         */
        PAUSED
    }

    private CameraKitHelper() {
    }

    /**
     * 初始化存储目录
     *
     * @param context 应用上下文
     */
    public static void initStoreDir(Context context) {
        Objects.requireNonNull(context, "app context should be not null!");
        File dir = context.getExternalFilesDir(null);
        if (dir == null) {
            Log.e(TAG, "context.getExternalFilesDir error");
            return;
        }
        String savePath;
        try {
            savePath = dir.getCanonicalPath();
        } catch (IOException e) {
            Log.e(TAG, "initStoreDir error" + e.getMessage());
            return;
        }
        imageSaveDir = savePath + File.separator + "HwCameraKit" + File.separator;
    }

    /**
     * 检查文件路径是否存在
     */
    public static void checkImageDirectoryExists() {
        File imageDirectory = new File(imageSaveDir);
        if (!imageDirectory.exists()) {
            if (imageDirectory.mkdirs()) {
                Log.d(TAG, "imageSaveDir:" + imageSaveDir);
            }
        }
    }

    /**
     * 根据模式得到文件名
     *
     * @param modeType 模式类型
     * @param tag 额外字符
     * @return 最终文件名
     */
    public static File setFileName(@Mode.Type int modeType, String tag) {
        Log.d(TAG, "setmFileName: ");
        String prefixFile;
        switch (modeType) {
            case Mode.Type.PRO_PHOTO_MODE:
                prefixFile = "ProPhoto";
                break;
            case Mode.Type.PRO_VIDEO_MODE:
                prefixFile = "ProVideo";
                break;
            default:
                prefixFile = "Default";
                break;
        }
        if (CONSTANT_RAW.equals(tag)) {
            return new File(imageSaveDir,
                    String.format(Locale.ENGLISH, "%s_%s_%d.dng", prefixFile, tag, System.currentTimeMillis()));
        } else {
            return new File(imageSaveDir,
                    String.format(Locale.ENGLISH, "%s_%s_%d.jpg", prefixFile, tag, System.currentTimeMillis()));
        }
    }

    /**
     * 检查集合是否为空指针或空集合
     *
     * @param collection 要检查的集合
     * @param <T> 集合泛型
     * @return true是空集合，反之非空
     */
    public static <T extends Collection<?>> boolean isEmptyCollection(T collection) {
        return (collection == null) || (collection.size() == 0);
    }

    /**
     * 两个面积比较函数.
     *
     * @since 2019-03-15
     */
    public static class CompareSizesByArea implements Comparator<Size> {
        @Override
        public int compare(Size lhs, Size rhs) {
            return Long.signum((long) lhs.getWidth() * lhs.getHeight() - (long) rhs.getWidth() * rhs.getHeight());
        }
    }

    /**
     * 检查数组是否包含string值
     *
     * @param collection 待检查的数组
     * @param value 要检查的string值
     * @return true是包含，反之不包含
     */
    public static boolean contains(List<CaptureRequest.Key<?>> collection, Object value) {
        if (collection == null) {
            return false;
        }
        return collection.contains(value);
    }

    /**
     * 基于录像的分辨率，获取录像中的抓拍分辨率
     *
     * @param videoSize 录像分辨率
     * @param captureSupports 支持的拍照分辨率集合
     * @return 抓拍分辨率
     */
    public static Size getSnapShotSize(Size videoSize, List<Size> captureSupports) {
        if ((captureSupports == null) || (videoSize == null)) {
            Log.e(TAG, "getSnapShotSize: error, captureSupports or videoSize is null");
            return null;
        }

        float ratio = ((float) (videoSize.getHeight())) / ((float) (videoSize.getWidth()));
        Size optimalSize = null;
        Size maxSize = new Size(0, 0);
        for (Size support : captureSupports) {
            if (Math.abs((((float) (support.getHeight())) / ((float) (support.getWidth())))
                    - ratio) < FLOAT_COMPARISON_TOLERANCE) {
                if ((optimalSize == null) || (optimalSize.getWidth() < support.getWidth())) {
                    optimalSize = support;
                }
            }
            if (isSupportMaxSize(optimalSize, maxSize, support)) {
                maxSize = support;
            }
        }
        if (optimalSize == null) {
            optimalSize = maxSize;
        }
        if ((optimalSize.getWidth() == 0) || (optimalSize.getHeight() == 0)) {
            optimalSize = videoSize;
        }
        if (isVideoSizeOptimal(videoSize, captureSupports)) {
            Log.d(TAG, "optimal video capture size is 4K.");
            optimalSize = videoSize;
        }
        Log.i(TAG, "optimal video capture size = " + optimalSize.getWidth() + "x" + optimalSize.getHeight());
        return optimalSize;
    }

    private static boolean isSupportMaxSize(Size optimalSize, Size maxSize, Size support) {
        return (optimalSize == null)
                && ((support.getWidth() > maxSize.getWidth()) || (support.getHeight() > maxSize.getHeight()));
    }

    private static boolean isVideoSizeOptimal(Size videoSize, List<Size> captureSupports) {
        return (videoSize.equals(RECORD_SOLUTION_4K)) && (captureSupports.contains(videoSize));
    }

    /**
     * get Video file path
     *
     * @return video file path
     */
    public static String getVideoName() {
        Log.d(TAG, "setmFileName: ");
        String prefixFile;
        prefixFile = "ProVideo";
        videoFilePath = imageSaveDir + prefixFile + "_video_" + System.currentTimeMillis() + ".mp4";
        return videoFilePath;
    }

    /**
     * get current video file name
     *
     * @return video file path
     */
    public static String getCurrentVideoFileName() {
        return videoFilePath;
    }

    /**
     * choose Optimal preview size according to record size
     *
     * @param context context
     * @param videoSize record resolution
     * @param cameraPreviewSupports preview sizes supported by the camera
     * @return preview size
     */
    public static Size getOptimalVideoPreviewSize(Context context, Size videoSize, List<Size> cameraPreviewSupports) {
        if ((context == null) || (videoSize == null) || (cameraPreviewSupports == null)) {
            Log.e(TAG, "getOptimalVideoPreviewSize: error, some parameter is null");
            return null;
        }

        Object obj = context.getSystemService(Context.WINDOW_SERVICE);
        WindowManager wm = null;
        if (obj instanceof WindowManager) {
            wm = (WindowManager) obj;
        }
        if (wm == null) {
            return null;
        }
        Display display = wm.getDefaultDisplay();
        if (display == null) {
            return null;
        }
        Point displaySize = new Point();
        display.getSize(displaySize);

        int maxPreviewWidth = displaySize.x;
        int maxPreviewHeight = displaySize.y;

        Size optimalSize = null;
        int maxValue = MAX_RESOLUTION_VALUE;
        double videoRatio = ((double) (videoSize.getWidth())) / ((double) (videoSize.getHeight()));
        for (Size size : cameraPreviewSupports) {
            if ((size.getWidth() > maxPreviewWidth) && (size.getHeight() > maxPreviewHeight)) {
                continue;
            }
            if (size.getHeight() > maxValue) {
                continue;
            } else if (Math
                .abs(((double) (size.getWidth())) / ((double) (size.getHeight())) - videoRatio) > RATIO_TOLERANCE) {
                continue;
            } else if (optimalSize == null) {
                optimalSize = size;
                continue;
            }
            if ((Math.abs(size.getHeight() - videoSize.getHeight()) <= Math
                .abs(optimalSize.getHeight() - videoSize.getHeight()))
                && (Math.abs(size.getWidth() - videoSize.getWidth()) <= Math
                    .abs(optimalSize.getWidth() - videoSize.getWidth()))) {
                optimalSize = size;
            }
        }
        Log.i(TAG, "optimal video preview size = "
            + ((optimalSize == null) ? "null" : (optimalSize.getWidth() + "x" + optimalSize.getHeight())));
        return optimalSize;
    }

    /**
     * get image rotation degree
     *
     * @param sensorOrientation sensor orientation
     * @param rotationDegree phone rotated degree
     * @return image rotation degree
     */
    public static int getImageRotation(int sensorOrientation, int rotationDegree) {
        Log.d(TAG, "getImageRotation: mSensorOrientation = " + sensorOrientation);
        int orientation = 0;
        if ((rotationDegree > (ROTATION_DEGREE_360 - ROTATION_DEGREE_30)) || (rotationDegree < ROTATION_DEGREE_30)) {
            orientation = ROTATION_DEGREE_0;
        } else if ((rotationDegree > (ROTATION_DEGREE_90 - ROTATION_DEGREE_30))
            && (rotationDegree < (ROTATION_DEGREE_90 + ROTATION_DEGREE_30))) {
            orientation = ROTATION_DEGREE_90;
        } else if ((rotationDegree > (ROTATION_DEGREE_180 - ROTATION_DEGREE_30))
            && (rotationDegree < (ROTATION_DEGREE_180 + ROTATION_DEGREE_30))) {
            orientation = ROTATION_DEGREE_180;
        } else if ((rotationDegree > (ROTATION_DEGREE_270 - ROTATION_DEGREE_30))
            && (rotationDegree < (ROTATION_DEGREE_270 + ROTATION_DEGREE_30))) {
            orientation = ROTATION_DEGREE_270;
        }
        int imageRotation = (orientation + sensorOrientation) % ROTATION_DEGREE_360;
        Log.d(TAG, "getImageRotation: imageRotation = " + imageRotation);
        return imageRotation;
    }
}
